DROP TABLE IF EXISTS courses_with_subcategories;
DROP SEQUENCE IF EXISTS global_seq_courses_with_subcategories;

DROP TABLE IF EXISTS comments;
DROP SEQUENCE IF EXISTS global_seq_comments;

DROP TABLE IF EXISTS courses;
DROP SEQUENCE IF EXISTS global_seq_courses;

DROP TABLE IF EXISTS courses_data;
DROP SEQUENCE IF EXISTS global_seq_courses_data;

DROP TABLE IF EXISTS subcategories;
DROP SEQUENCE IF EXISTS global_seq_subcategories;

DROP TABLE IF EXISTS categories;
DROP SEQUENCE IF EXISTS global_seq_categories;

DROP TABLE IF EXISTS users;
DROP SEQUENCE IF EXISTS global_seq_users;

DROP TABLE IF EXISTS schools_data;
DROP SEQUENCE IF EXISTS global_seq_schools_data;

DROP TABLE IF EXISTS schools;
DROP SEQUENCE IF EXISTS global_seq_schools;

CREATE SEQUENCE global_seq_users START WITH 1 INCREMENT BY 1;
CREATE TABLE users
(
    id         BIGINT PRIMARY KEY DEFAULT nextval('global_seq_users'),
    first_name VARCHAR(20) NOT NULL,
    last_name  VARCHAR(20) NOT NULL,
    email      VARCHAR(30),--NOT NULL,
    phone      VARCHAR(12),--NOT NULL,
    secret     VARCHAR(100) --NOT NULL

);
CREATE UNIQUE INDEX users_unique_email_idx ON users (email);
CREATE UNIQUE INDEX users_unique_phone_idx ON users (phone);



CREATE SEQUENCE global_seq_schools START WITH 3000 INCREMENT BY 1;
CREATE TABLE schools
(
    id     BIGINT PRIMARY KEY DEFAULT nextval('global_seq_schools'),
    email  VARCHAR(30)  NOT NULL,
    phone  VARCHAR(12)  NOT NULL,
    secret VARCHAR(100) NOT NULL
);
CREATE UNIQUE INDEX schools_unique_email_idx ON users (email);



CREATE SEQUENCE global_seq_schools_data START WITH 3000 INCREMENT BY 1;
CREATE TABLE schools_data
(
    id          BIGINT PRIMARY KEY DEFAULT nextval('global_seq_schools_data'),
    name        VARCHAR,
    logo        VARCHAR,
    description TEXT,
    link        VARCHAR,
    native_name VARCHAR(50),
    school_id   BIGINT,
    rating      FLOAT default 0.0,
    FOREIGN KEY (school_id)
        REFERENCES schools (id)
        ON DELETE CASCADE
);

CREATE SEQUENCE global_seq_categories START WITH 3000 INCREMENT BY 1;
CREATE TABLE categories
(
    id          BIGINT PRIMARY KEY DEFAULT nextval('global_seq_categories'),
    name        VARCHAR NOT NULL,
    native_name VARCHAR NOT NULL

);


CREATE SEQUENCE global_seq_subcategories START WITH 3000 INCREMENT BY 1;
CREATE TABLE subcategories
(
    id                          BIGINT PRIMARY KEY DEFAULT nextval('global_seq_subcategories'),
    name                        VARCHAR NOT NULL,
    native_name                 VARCHAR,
    description                 TEXT,
    terms_must_explanation      VARCHAR,
    terms_desirable_explanation VARCHAR,
    terms_possible_explanation  VARCHAR,
    description_length          INT,
    quality_description         INT,
    category_id                 BIGINT  NOT NULL,
    FOREIGN KEY (category_id)
        REFERENCES categories (id)
);
--
-- CREATE SEQUENCE global_seq_courses_data START WITH 1 INCREMENT BY 1;
-- CREATE TABLE courses_data
-- (
--     id                 BIGINT PRIMARY KEY DEFAULT nextval('global_seq_courses_data'),
--     difficulty         VARCHAR NOT NULL,
--     format             VARCHAR NOT NULL,
--     credit             VARCHAR NOT NULL,
--     education_period   VARCHAR NOT NULL,
--     start_date         VARCHAR NOT NULL,
--     work_guarantee     VARCHAR NOT NULL,
--     qualification_docs VARCHAR NOT NULL,
--     license            VARCHAR NOT NULL,
--     type_education     VARCHAR NOT NULL
--
-- );
--
CREATE SEQUENCE global_seq_courses START WITH 3000 INCREMENT BY 1;
CREATE TABLE courses
(
    id                 BIGINT PRIMARY KEY DEFAULT nextval('global_seq_courses'),
    name               VARCHAR NOT NULL,
    native_name        VARCHAR,
    school_data_id     BIGINT  NOT NULL,
    link               VARCHAR,
    logo               VARCHAR,
--     subcategory_id     BIGINT  NOT NULL,
    utm                VARCHAR,
    format             VARCHAR,
    difficulty         VARCHAR,
    price              INT,
    price_period       VARCHAR,
    education_period   VARCHAR,
    start_date         VARCHAR,
    qualification_docs VARCHAR,
    description        VARCHAR,
    promo              VARCHAR,
    rating             FLOAT              default 0,
--     course_data_id     BIGINT  NOT NULL,
--     FOREIGN KEY (subcategory_id)
--         REFERENCES subcategories (id),
    FOREIGN KEY (school_data_id)
        REFERENCES schools_data (id)
--     FOREIGN KEY (course_data_id)
--         REFERENCES courses_data (id)
);

CREATE SEQUENCE global_seq_courses_with_subcategories START WITH 3000 INCREMENT BY 1;
CREATE TABLE courses_with_subcategories
(
    id             BIGINT PRIMARY KEY DEFAULT nextval('global_seq_courses_with_subcategories'),
    course_id      BIGINT NOT NULL,
    subcategory_id BIGINT NOT NULL,
    FOREIGN KEY (course_id)
        REFERENCES courses (id),
    FOREIGN KEY (subcategory_id)
        REFERENCES subcategories (id)

);

CREATE SEQUENCE global_seq_comments START WITH 3000 INCREMENT BY 1;
CREATE TABLE comments
(
    id             BIGINT PRIMARY KEY DEFAULT nextval('global_seq_comments'),
    date           DATE    NOT NULL,
    score          FLOAT   NOT NULL,
    title          VARCHAR default null,
    content        TEXT    NOT NULL,
    user_id        BIGINT             default null,
    nickname       varchar(30)        default null,
    school_data_id BIGINT  NOT NULL,
    course_id      BIGINT             default null,

    FOREIGN KEY (user_id)
        REFERENCES users (id),
    FOREIGN KEY (school_data_id)
        REFERENCES schools_data (id),
    FOREIGN KEY (course_id)
        REFERENCES courses (id)


);
--
-- CREATE TABLE comments_for_school
-- (
--     id             BIGINT PRIMARY KEY DEFAULT nextval('global_seq_comments'),
--     date           DATE NOT NULL,
--     score          INT       NOT NULL,
--     title          VARCHAR   NOT NULL,
--     user_id        BIGINT    NOT NULL,
--     school_data_id BIGINT    NOT NULL,
--     FOREIGN KEY (user_id)
--         REFERENCES users (id),
--     FOREIGN KEY (school_data_id)
--         REFERENCES schools_data (id)
-- );
--
-- CREATE TABLE comments_for_course_external
-- (
--     id             BIGINT PRIMARY KEY DEFAULT nextval('global_seq_comments'),
--     date           DATE NOT NULL,
--     score          INT       NOT NULL,
--     title          VARCHAR   NOT NULL,
--     content        TEXT      NOT NULL,
--     nickname       VARCHAR   NOT NULL,
--     school_data_id BIGINT    NOT NULL,
--     course_id      BIGINT    NOT NULL,
--     FOREIGN KEY (course_id)
--         REFERENCES courses (id),
--     FOREIGN KEY (school_data_id)
--         REFERENCES schools_data (id)
-- );
--
-- CREATE TABLE comments_for_school_external
-- (
--     id             BIGINT PRIMARY KEY DEFAULT nextval('global_seq_comments'),
--     date           DATE NOT NULL,
--     score          INT       NOT NULL,
--     title          VARCHAR   NOT NULL,
--     content        TEXT      NOT NULL,
--     nickname       VARCHAR   NOT NULL,
--     school_data_id BIGINT    NOT NULL,
--     FOREIGN KEY (school_data_id)
--         REFERENCES schools_data (id)
-- );






