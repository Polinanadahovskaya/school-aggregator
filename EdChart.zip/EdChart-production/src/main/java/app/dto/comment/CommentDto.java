package app.dto.comment;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentDto {
    @JsonProperty
    private Long id;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    @JsonProperty
    private LocalDate date;
    @JsonProperty
    private float score;
    @JsonProperty
    private String title;
    @JsonProperty
    private String content;
    @JsonProperty
    private String nickname;
    @JsonProperty
    private Long schoolDataId;
    @JsonProperty
    private Long courseId;
    @JsonProperty
    private Long userId;

    @Override
    public String toString() {
        return "CommentDto{" +
                "id=" + id +
                ", date=" + date +
                ", score=" + score +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", nickname='" + nickname + '\'' +
                ", schoolDataId=" + schoolDataId +
                ", courseId=" + courseId +
                ", userId=" + userId +
                '}';
    }
}
