package app.dto.comment;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentPagingDto {

    public List<CommentDto> commentDtoList;
    public boolean hasNext;

}
