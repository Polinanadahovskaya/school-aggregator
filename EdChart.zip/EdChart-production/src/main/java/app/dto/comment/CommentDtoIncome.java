package app.dto.comment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommentDtoIncome {

    @JsonProperty
    private float score;
    @JsonProperty
    private String title;
    @JsonProperty
    private String content;
    @JsonProperty
    private String nickname;
    @JsonProperty
    private Long schoolDataId;
    @JsonProperty
    private Long courseId;
    @JsonProperty
    private Long userId;

    @Override
    public String toString() {
        return "CommentDtoIncome{" +
                "score=" + score +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", nickname='" + nickname + '\'' +
                ", schoolDataId=" + schoolDataId +
                ", courseId=" + courseId +
                ", userId=" + userId +
                '}';
    }
}
