package app.dto.categories;

import app.dto.subcategories.SubcategoriesDto;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CategoriesDto {

    private Long id;

    private String name;

    private String nativeName;

    private List<SubcategoriesDto> subcategoriesList;

}
