package app.dto.subcategories;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class SubcategoriesDto {

    private Long id;

    private String name;

    private String nativeName;
    private String description;
    private String termMustExplanation;
    private String termDesirableExplanation;
    private String termPossibleExplanation;
    private int descriptionLength;
    private int qualityDescription;
}
