package app.dto.subcategories;

import app.dto.course.CourseDto;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class SubcategoriesWithCoursesDto extends SubcategoriesDto {

    private Set<CourseDto> coursesSet;

}
