package app.dto.course;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CourseFeedbackDto {
    private Long id;
    private String name;
}
