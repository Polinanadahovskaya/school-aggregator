package app.dto.course;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CourseDto {

    private Long id;

    private String name;

    private String nativeName;

    private String link;

    private String logo;

    private String utm;

    private String format;

    private String difficulty;

    private Integer price;

    private String pricePeriod;

    private String educationPeriod;

    private String startDate;

    private String qualificationDocs;

    private String description;

    private String promo;

    private Float rating;

    private Long schoolDataId;

    private String schoolName;

    private String schoolLogo;

    //private Set<SubcategoriesDto> coursesDataList;

}
