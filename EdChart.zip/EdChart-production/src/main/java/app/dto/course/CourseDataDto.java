package app.dto.course;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CourseDataDto {

    private Long id;

    private String difficulty;

    private String format;

    private String credit;

    private String educationPeriod;

    private String startDate;

    private String guarantee;

    private String qualificationDocs;

    private String license;

    private String typeEducation;


}
