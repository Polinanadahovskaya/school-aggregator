package app.dto.schooldata;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SchoolDataRatingCountFeedbacksDto {

    private Long id;
    private String name;
    private String nativeName;
    private String logo;
    private String description;
    private String link;
    private Float rating;
    private Long feedbacks;

    private Integer positiveFeedbacks;
    private Integer neutralFeedbacks;
    private Integer negativeFeedbacks;

    private Long toplist;

}
