package app.dto.schooldata;

import app.dto.comment.CommentDto;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SchoolDataWithCountFBsAndTypesFBsPagingDto {

    public List<SchoolDataWithCountFBsAndTypesFBsDto> schoolDataWithCountFBsAndTypesFBsDtoList;
    public boolean hasNext;
}
