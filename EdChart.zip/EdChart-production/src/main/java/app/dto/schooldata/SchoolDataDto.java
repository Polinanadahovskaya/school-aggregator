package app.dto.schooldata;

import app.model.School;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SchoolDataDto {

    private Long id;
    private String name;
    private String nativeName;
    private String logo;
    private String description;
    private String link;
    private Float rating;

}
