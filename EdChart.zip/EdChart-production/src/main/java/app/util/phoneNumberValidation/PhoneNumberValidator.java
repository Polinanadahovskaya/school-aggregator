package app.util.phoneNumberValidation;

import app.util.phoneNumberValidation.annotation.PhoneNumber;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Configurable
public class PhoneNumberValidator implements ConstraintValidator<PhoneNumber, String> {

    private static final String PHONE_NUMBER_REGEX = "^((\\+7|7|8)+([0-9]){10})$";

    private static final Pattern PHONE_NUMBER_PATTERN =Pattern.compile(PHONE_NUMBER_REGEX);

    @Override
    public void initialize(PhoneNumber constraintAnnotation) {

    }

    @Override
    public boolean isValid(String phoneNumber, ConstraintValidatorContext context) {

        Matcher matcher = PHONE_NUMBER_PATTERN.matcher(phoneNumber);

        return matcher.matches();

    }

}

