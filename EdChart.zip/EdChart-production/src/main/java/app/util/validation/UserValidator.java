package app.util.validation;

import app.dto.UserDto;
import app.model.User;
import app.service.EqualService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.Optional;

@Component
public class UserValidator implements Validator {

    private final EqualService equalService;

    @Autowired
    public UserValidator(EqualService equalService) {
        this.equalService = equalService;
    }


    @Override
    public boolean supports(Class<?> aClass) {
        return User.class.equals(aClass);
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserDto userDto = (UserDto) target;

        Optional<User> userForEmail = equalService.defineUserByEmail(userDto.getEmail());
        Optional<User> userForPhone = equalService.defineUserByPhone(userDto.getPhone());

        if (!userForEmail.isEmpty()) {
            errors.rejectValue("Email", "",
                    "A user with this email already exists, " +
                            "your email must be unique to register.");

        } else if (!userForPhone.isEmpty()) {
            errors.rejectValue("Phone", "",
                    "A user with this phone number already exists, " +
                            "your phone number must be unique to register.");
        }


    }

}