package app.repository;

import app.dto.comment.CommentDto;
import app.dto.course.CourseDto;
import app.model.Comment;
import app.model.sql.SqlCountRating;
import app.model.sql.SqlCountTypeFeedbacksSchoolData;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    List<Comment> findCommentBySchoolDataId(Long schoolDataId);

    @Query(value = "select a.id as id,b.count as count \n" +
            "        from schools_data as A\n" +
            "        inner join (select school_data_id,\n" +
            "        sum(score),\n" +
            "        count(school_data_id)\n" +
            "        from comments\n" +
            "        group by school_data_id) as B on a.id = b.school_data_id where id =:id", nativeQuery = true)
        //exclude courses in future
    SqlCountRating getCountFeedbacksAndRating(Long id); //just one row we can receive

    @Query(nativeQuery = true, value = "SELECT * FROM comments where school_data_id = (select id from schools_data where native_name = :native_name) LIMIT 10")
    public List<Comment> find10Comment(String native_name);

    @Query(value = "SELECT\n" +
            "  COUNT(1) FILTER (WHERE score >= 4.0) AS positiveFeedbacks,\n" +
            "  COUNT(1) FILTER (WHERE score <=3.99 and score >=3.0) AS neutralFeedbacks,\n" +
            "  COUNT(1) FILTER (WHERE score <3.99) AS negativeFeedbacks\n" +
            "FROM comments where school_data_id =:id", nativeQuery = true)
    SqlCountTypeFeedbacksSchoolData getCountTypeFeedbacks(Long id);

    public Slice<Comment> findCommentsBySchoolDataId(Long schoolId, Pageable pageable);

}
