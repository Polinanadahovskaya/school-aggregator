package app.repository;

import app.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long> {

    public Course findCourseDataByNativeName(String name);


    public Course findCourseBySchoolDataIdAndId(Long schoolId, Long courseId);

    public List<Course> findCoursesBySchoolDataId(Long schoolId);

    @Query(nativeQuery = true, value = "select name as name from schools_data where id =:id ")
    public String getSchoolNameFromDB(long id);

    @Query(nativeQuery = true, value = "select logo as logo from schools_data where id =:id ")
    public String getSchoolLogoFromDB(long id);

}
