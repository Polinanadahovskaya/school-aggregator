package app.repository;

import app.model.Subcategories;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SubcategoriesRepository extends JpaRepository<Subcategories, Long>  {

    Optional<Subcategories> findSubcategoriesByNativeName(String name);

}
