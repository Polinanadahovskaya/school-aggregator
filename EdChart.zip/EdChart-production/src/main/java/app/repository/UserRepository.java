package app.repository;

import app.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    public Optional<User> findUserByFirstName(String firstName);

    public Optional<User> findUserByLastName(String lastName);

    public Optional<User> findUserByEmail(String email);

    public Optional<User> findUserByPhone(String phone);

    public User getUserByFirstName(String firstName);

    public User getUserByLastName(String lastName);

    public User getUserByEmail(String email);

    public User getUserByPhone(String phone);

}
