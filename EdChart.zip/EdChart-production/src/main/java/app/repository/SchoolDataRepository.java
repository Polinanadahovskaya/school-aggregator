package app.repository;

import app.model.SchoolData;
import app.model.sql.SqlSchoolDataTopList;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SchoolDataRepository extends JpaRepository<SchoolData, Long> {

    public SchoolData findSchoolDataByNativeName(String schoolName);

    @Query(nativeQuery = true, value = "SELECT row_number() over(ORDER BY rating DESC ) as toplist, id,name,logo,description,link,native_name as nativeName, school_id, rating FROM schools_data LIMIT 15")
    public List<SqlSchoolDataTopList> findTop15ByRating();


    @Query(nativeQuery = true, value = "SELECT row_number() over(ORDER BY rating DESC ) as toplist , id,name,logo,description,link,native_name as nativeName, school_id, rating FROM schools_data")
    public Slice<SqlSchoolDataTopList>  findAllSchoolData(Pageable pageable);

}