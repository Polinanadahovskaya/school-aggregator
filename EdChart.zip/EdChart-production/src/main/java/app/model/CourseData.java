package app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "courses_data")
public class CourseData {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "global_seq_courses_data")
    @SequenceGenerator(name = "global_seq_courses_data", sequenceName = "global_seq_courses_data", allocationSize = 1)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "difficulty", nullable = false)
    @NotBlank
    private String difficulty;

    @Column(name = "format", nullable = false)
    @NotBlank
    private String format;

    @Column(name = "credit", nullable = false)
    @NotBlank
    private String credit;

    @Column(name = "education_period", nullable = false)
    @NotBlank
    private String educationPeriod;

    @Column(name = "start_date", nullable = false)
    @NotBlank
    private String startDate;

    @Column(name = "work_guarantee", nullable = false)
    @NotBlank
    private String guarantee;

    @Column(name = "qualification_docs", nullable = false)
    @NotBlank
    private String qualificationDocs;

    @Column(name = "license", nullable = false)
    @NotBlank
    private String license;

    @Column(name = "type_education", nullable = false)
    @NotBlank
    private String typeEducation;

}