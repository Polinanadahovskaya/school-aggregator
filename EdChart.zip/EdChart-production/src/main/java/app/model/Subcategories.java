package app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "subcategories")
public class Subcategories {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "global_seq_subcategories")
    @SequenceGenerator(name = "global_seq_subcategories", sequenceName = "global_seq_subcategories", allocationSize = 1)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name", nullable = false)
    @NotBlank
    private String name;

    @Column(name = "native_name", nullable = false)
    @NotBlank
    private String nativeName;

    @Column(name = "description")
    private String description;

    @Column(name = "terms_must_explanation")
    private String termMustExplanation;

    @Column(name = "terms_desirable_explanation")
    private String termDesirableExplanation;

    @Column(name = "terms_possible_explanation")
    private String termPossibleExplanation;

    @Column(name = "description_length")
    private Integer descriptionLength;

    @Column(name = "quality_description")
    private String qualityDescription;

    @ManyToMany(mappedBy = "subcategoriesSet")
    private Set<Course> coursesSet = new HashSet<>();



//    @OneToMany(fetch = FetchType.LAZY)
//    @Fetch(FetchMode.SUBSELECT)
//    @JoinColumn(name = "subcategory_id", referencedColumnName = "id") //поле куда затем поле в этой таблице
//    private List<Course> courses;


}
