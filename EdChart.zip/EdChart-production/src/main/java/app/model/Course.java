package app.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "global_seq_courses")
    @SequenceGenerator(name = "global_seq_courses", sequenceName = "global_seq_courses", allocationSize = 1)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name", nullable = false)
    @NotBlank
    private String name;

    @Column(name = "native_name", nullable = false)
    @NotBlank
    private String nativeName;


    @Column(name = "link")
    @NotBlank
    private String link;

    @Column(name = "logo")
    @NotBlank
    private String logo;

    @Column(name = "utm")
    private String utm;

    @Column(name = "format")
    private String format;

    @Column(name = "difficulty")
    private String difficulty;

    @Column(name = "price", nullable = false)
    @NotBlank
    private Integer price;

    @Column(name = "price_period", nullable = false)
    @NotBlank
    private String pricePeriod;

    @Column(name = "education_period")
    private String educationPeriod;

    @Column(name = "start_date")
    private String startDate;

    @Column(name = "qualification_docs")
    private String qualificationDocs;

    @Column(name = "description")
    private String description;

    @Column(name = "promo")
    private String promo;

    @Column(name = "rating", nullable = false)
    @NotBlank
    private Float rating;

    @Column(name = "school_data_id", nullable = false)
    private Long schoolDataId;

    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(
            name = "courses_with_subcategories",
            joinColumns = {@JoinColumn(name = "course_id")},
            inverseJoinColumns = {@JoinColumn(name = "subcategory_id")}
    )
    @NotBlank
    private Set<Subcategories> subcategoriesSet;

}
