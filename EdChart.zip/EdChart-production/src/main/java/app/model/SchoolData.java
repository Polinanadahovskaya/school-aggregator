package app.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "schools_data")
public class SchoolData {




    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "global_seq_schools_data")
    @SequenceGenerator(name = "global_seq_schools_data", sequenceName = "global_seq_schools_data", allocationSize = 1)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "native_name")
    private String nativeName;

    @Column(name = "logo", nullable = false)
    private String logo;

    @Column(name = "description")
    private String description;

    @Column(name = "link", nullable = false)
    private String link;

    @Column(name = "rating", nullable = false)
    private Float rating;

    @OneToOne
    @JoinColumn(name = "school_id")
    private School school;

    //private Long toplist; //поле для присвоения рейтинга, поле динамическое, хранить его не нужно

    @Override
    public String toString() {
        return "SchoolData{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", link='" + link + '\'' +
                ", logo='" + logo + '\'' +
                ", school=" + school +
                ", rating=" + rating +
                '}';
    }
}