package app.model.sql;

import app.model.School;

public interface SqlSchoolDataTopList {


    Long getId();

    String getName();

    String getLogo();

    String getDescription();

    String getLink();

    String getNativeName();

    School getSchool();

    Float getRating();

    Long getToplist(); //поле для присвоения рейтинга, поле динамическое, хранить его не нужно


}
