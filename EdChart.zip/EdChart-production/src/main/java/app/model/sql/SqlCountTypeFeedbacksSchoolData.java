package app.model.sql;

public interface SqlCountTypeFeedbacksSchoolData {

    Integer getPositiveFeedbacks();

    Integer getNeutralFeedbacks();

    Integer getNegativeFeedbacks();
}
