package app.model.sql;

import lombok.Data;


public interface SqlCountRating {
     Long getId();
     Long getCount();

     //Float getRating();
}
