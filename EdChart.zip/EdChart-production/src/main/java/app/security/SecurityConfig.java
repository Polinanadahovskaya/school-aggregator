package app.security;


import app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
@ComponentScan("app.security")
public class SecurityConfig implements WebMvcConfigurer {

    private final CustomAuthProvider customAuthProvider;
    private final UserService userService;

    @Autowired
    public SecurityConfig(CustomAuthProvider customAuthProvider, UserService userService) {
        this.customAuthProvider = customAuthProvider;
        this.userService = userService;
    }


    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http

                .requiresChannel(chanel -> chanel.anyRequest().requiresSecure())
                .csrf(csrf -> csrf.disable())

                .authorizeHttpRequests(auth -> {
                    auth
                            .requestMatchers(HttpMethod.GET, "/js/*", "/styles/*", "/assets/*").permitAll()
                            .requestMatchers("/registration", "/registration/save", "/login", "/error").permitAll()
                            .requestMatchers("/courses/**", "/categories/**", "/subcategories/**").permitAll()
                            .requestMatchers("/comments/**").permitAll()
                            .requestMatchers("/school-data", "/school-data/**").permitAll()
                            .anyRequest().authenticated();

                })

                .formLogin(formLogin -> {
                    formLogin.loginPage("/login");
                    formLogin.loginProcessingUrl("/login");
                    formLogin.usernameParameter("email");
                    formLogin.defaultSuccessUrl("/welcome", true);
                    formLogin.failureUrl("/login?error");
                })

                .logout()
                .logoutUrl("/logout")
                .logoutSuccessUrl("/html/login")

                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")

                .and()

                .httpBasic(Customizer.withDefaults())

                .build();
    }

    @Bean
    public static PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.authenticationProvider(customAuthProvider);
        return authenticationManagerBuilder.build();
    }

    @Bean
    public DaoAuthenticationProvider authProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("https://edchart.ru")
//                .allowedOrigins("http://89.108.76.144:5173")
//                .allowedOrigins("http://89.108.76.144")
//                .allowedOrigins("http://localhost:5173")
//                .allowedOrigins("http://localhost:5173")
////
//                .allowedOrigins("http://89.108.76.144:8080")
//                .allowedOrigins("http://localhost:8080")

//                .allowedOrigins("*")
                .allowedMethods("*");
    }
}
