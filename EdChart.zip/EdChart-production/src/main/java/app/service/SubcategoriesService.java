package app.service;

import app.dto.subcategories.SubcategoriesWithCoursesDto;
import app.exception.EntityNotFoundException;
import app.mapper.SubcategoriesWithCoursesMapper;
import app.model.Subcategories;
import app.repository.SubcategoriesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SubcategoriesService {

    private final SubcategoriesRepository subcategoriesRepository;

    @Autowired
    public SubcategoriesService(SubcategoriesRepository subcategoriesRepository) {
        this.subcategoriesRepository = subcategoriesRepository;
    }

    public SubcategoriesWithCoursesDto findSubcategoryWithCoursesById(Long subcategoryId) {
        Optional<Subcategories> subcategory = subcategoriesRepository.findById(subcategoryId);
        if (subcategory.isPresent()) {
            return SubcategoriesWithCoursesMapper.SUBCATEGORIESWITHCOURSES_MAPPER.mapToDto(subcategory.get());
        } else {
            throw new EntityNotFoundException("SubcategoriesWithCoursesDto: ", subcategoryId.intValue(), "not found in DB");
        }
    }

    public SubcategoriesWithCoursesDto findSubcategoryWithCoursesByName(String subcategoryName) {
        Optional<Subcategories> subcategory = subcategoriesRepository.findSubcategoriesByNativeName(subcategoryName);
        if (subcategory.isPresent()) {
            return SubcategoriesWithCoursesMapper.SUBCATEGORIESWITHCOURSES_MAPPER.mapToDto(subcategory.get());
        } else {
            throw new EntityNotFoundException("SubcategoriesWithCoursesDto: ", subcategoryName, "not found in DB");
        }
    }

}
