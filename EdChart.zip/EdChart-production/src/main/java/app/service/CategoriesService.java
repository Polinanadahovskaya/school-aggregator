package app.service;

import app.dto.categories.CategoriesDto;
import app.exception.EntityNotFoundException;
import app.mapper.CategoriesMapper;
import app.model.Categories;
import app.repository.CategoriesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriesService {


    private final CategoriesRepository categoriesRepository;

    @Autowired
    public CategoriesService(CategoriesRepository categoriesRepository) {
        this.categoriesRepository = categoriesRepository;
    }

    public List<CategoriesDto> findAll() {
        return categoriesRepository.findAll().stream()
                .map(CategoriesMapper.CATEGORIES_MAPPER::mapToDto)
                .toList();
    }

    public CategoriesDto findById(Long id) {
        Optional<Categories> category = categoriesRepository.findById(id);
        if (category.isPresent()) {
            return CategoriesMapper.CATEGORIES_MAPPER.mapToDto(category.get());
        } else {
            throw new EntityNotFoundException("CategoryDto: ", id.intValue(), "not found in DB");
        }
    }

    public CategoriesDto findByCategoryNativeName(String categoryName)
    {
        Optional<Categories> category = categoriesRepository.findCategoriesByNativeName(categoryName);

        if (category.isPresent()) {
            return CategoriesMapper.CATEGORIES_MAPPER.mapToDto(category.get());
        } else {
            throw new EntityNotFoundException("CategoryDto: ", categoryName , "not found in DB");
        }
    }
}
