package app.service;

import app.dto.schooldata.SchoolDataWithCountFBsAndTypesFBsDto;
import app.dto.schooldata.SchoolDataWithCountFBsAndTypesFBsPagingDto;
import app.mapper.SchoolDataMapper;
import app.mapper.SchoolDataSpecialMapper;
import app.model.SchoolData;
import app.model.sql.SqlSchoolDataTopList;
import app.repository.CommentRepository;
import app.repository.SchoolDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SchoolService extends SchoolDataSpecialMapper {

    private final SchoolDataSpecialMapper schoolDataSpecialMapper;
    private final SchoolDataRepository schoolDataRepository;
    private final CommentRepository commentRepository;


    @Autowired
    public SchoolService(SchoolDataSpecialMapper schoolDataSpecialMapper,
                         SchoolDataRepository schoolDataRepository,
                         CommentRepository commentRepository) {
        this.schoolDataSpecialMapper = schoolDataSpecialMapper;
        this.schoolDataRepository = schoolDataRepository;
        this.commentRepository = commentRepository;
    }


    //get school by native name
    public SchoolDataWithCountFBsAndTypesFBsDto getSchool(String schoolName) {
        //может школы не быть! сделать проверку
        SchoolData schoolDataByNativeName = schoolDataRepository.findSchoolDataByNativeName(schoolName);

        SchoolDataWithCountFBsAndTypesFBsDto result = SchoolDataMapper.SCHOOL_DATA_MAPPER.mapToDtoWithAdditionalData(schoolDataByNativeName, commentRepository);

        //переменная toplist будет пустой
        return result;
    }

    // -
    public List<SchoolDataWithCountFBsAndTypesFBsDto> getRatingsAndFeedBacksForAllSchools() {

        List<SqlSchoolDataTopList> top15ByRating = schoolDataRepository.findTop15ByRating();

        top15ByRating.forEach(item -> System.out.println(item.getNativeName()));


        List<SchoolDataWithCountFBsAndTypesFBsDto> result = top15ByRating.stream()
                .map(item -> SchoolDataMapper.SCHOOL_DATA_MAPPER.mapFromSqlToDto(item, commentRepository))
                .toList();

        return result;
    }

    //C помощью sql запроса получаем порциб данных отсортированных в обратном порядке по рейтингу
    //с присвоением каждой строке номера означающего позицию в топлисте
    //
    public SchoolDataWithCountFBsAndTypesFBsPagingDto getRatingsByPortions(int pageNo, int pageSize) {
        PageRequest pageRequest = PageRequest.of(pageNo, pageSize);

        Slice<SqlSchoolDataTopList> request = schoolDataRepository.findAllSchoolData(pageRequest);

        List<SqlSchoolDataTopList> content = request.getContent();

        List<SchoolDataWithCountFBsAndTypesFBsDto> schoolDataWithCountFBsAndTypesFBsDtos = content.stream()
                .map(item -> SchoolDataMapper.SCHOOL_DATA_MAPPER.mapFromSqlToDto(item, commentRepository))
                .toList();


        SchoolDataWithCountFBsAndTypesFBsPagingDto result = new SchoolDataWithCountFBsAndTypesFBsPagingDto();


        result.setSchoolDataWithCountFBsAndTypesFBsDtoList(schoolDataWithCountFBsAndTypesFBsDtos);

        result.setHasNext(request.hasNext());

        return result;
    }

}