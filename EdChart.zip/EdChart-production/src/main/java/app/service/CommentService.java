package app.service;

import app.dto.comment.CommentDto;
import app.dto.comment.CommentDtoIncome;
import app.dto.comment.CommentPagingDto;
import app.mapper.CommentMapper;
import app.model.Comment;
import app.model.User;
import app.repository.CommentRepository;
import app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class CommentService {

    //int BATCH_SIZE = 10;

    private final CommentRepository commentRepository;
    private final UserRepository userRepository;

    @Autowired
    public CommentService(CommentRepository commentRepository, UserRepository userRepository) {
        this.commentRepository = commentRepository;
        this.userRepository = userRepository;
    }

//    public List<CommentDto> findAllCommentsSchool(Long schoolDataId) {
//        return commentRepository.findCommentBySchoolDataId(schoolDataId).stream()
//                .map(CommentMapper.COMMENT_MAPPER::mapToDto)
//                .toList();
//    }

    public List<CommentDto> find10CommentsSchool(String schoolDataNativeName) {
        return commentRepository.find10Comment(schoolDataNativeName).stream()
                .map(CommentMapper.COMMENT_MAPPER::mapToDto)
                .toList();
    }

    public CommentDto saveComment(CommentDtoIncome commentDtoIncome) {

        if (commentDtoIncome.getUserId() == null) {
            commentDtoIncome.setUserId(2L);
        }

        Optional<User> user = userRepository.findById(commentDtoIncome.getUserId());

        String nickname = null;

        if (user.isPresent()) {

            nickname = user.get().getFirstName() + " " + user.get().getLastName();
        } else {
            nickname = "Test, not authorised user";
        }
        commentDtoIncome.setNickname(nickname);
        CommentDto commentDto = CommentMapper.COMMENT_MAPPER.mapToDtoFromIncome(commentDtoIncome);
        commentDto.setDate(LocalDate.now());
        return CommentMapper.COMMENT_MAPPER.mapToDto(commentRepository.save(CommentMapper.COMMENT_MAPPER.mapFromDto(commentDto)));
    }


    public CommentPagingDto processCommentsByPortions(Long schoolId, int pageNo, int pageSize) {

        //preparing request
        PageRequest pageRequest = PageRequest.of(pageNo, pageSize);
        //pass it to repos
        Slice<Comment> request = commentRepository.findCommentsBySchoolDataId(schoolId, pageRequest);

        CommentPagingDto result = new CommentPagingDto();
        result.setCommentDtoList(request.getContent().stream().map(CommentMapper.COMMENT_MAPPER::mapToDto).toList());
        result.setHasNext(request.hasNext());

        return result;
    }


}
