package app.service;

import app.dto.course.CourseDto;
import app.dto.course.CourseFeedbackDto;
import app.mapper.CourseMapper;
import app.model.Course;
import app.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    @Autowired
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public List<CourseDto> findAll() {
        return courseRepository.findAll().stream()
                .map(CourseMapper.COURSE_MAPPER::mapToDto)
                .toList();
    }

    public CourseDto findById(long id) {
        return CourseMapper.COURSE_MAPPER
                .mapToDto(courseRepository.findById(id).get());
    }

    public CourseDto findByNativeName(String name) {

        return CourseMapper.COURSE_MAPPER
                .mapToDto(courseRepository.findCourseDataByNativeName(name));
    }

    public List<CourseDto> getRandom(Long schoolId, Long repeat) {
        long min = 0L;
        long max = 0L;
        Long random = 0L;
        List<CourseDto> result = new ArrayList<>();

        if (schoolId == 0) { //random courses
            //System.out.println("Ищем случайные курсы по всей базе");
            min = 2L; //minimum course id = 2
            max = courseRepository.findAll().size() + 1; // maximun course id = 35
            //дополнительная проверка что если запросили курсов больше чем есть в школе
            if (repeat > max) {
                repeat = max;
            }
            for (int i = 0; i < repeat; i++) {

                random = min + (long) (Math.random() * ((max - min) + 1));
                result.add(CourseMapper.COURSE_MAPPER.mapToDto(courseRepository.findById(random).get()));
            }
        } else { //random courses from school
            //System.out.println("Ищем случайные курсы по школе");
            List<Course> coursesBySchoolDataId = courseRepository.findCoursesBySchoolDataId(schoolId);
            //дополнительная проверка что если запросили курсов больше чем есть в школе
            if (repeat > coursesBySchoolDataId.size()) {
                repeat = (long) coursesBySchoolDataId.size();
            }
            for (int i = 0; i < repeat; i++) {
                min = 0;
                max = coursesBySchoolDataId.size() - 1;//list begins from 0!
                random = min + (long) (Math.random() * ((max - min) + 1));
                result.add(CourseMapper.COURSE_MAPPER.mapToDto(courseRepository.findCourseBySchoolDataIdAndId(schoolId, coursesBySchoolDataId.get(random.intValue()).getId())));
                coursesBySchoolDataId.remove(random.intValue());//после курс из листа нужно удалить так как он может потенциально выпасть снова
            }

        }

        for (CourseDto dto : result) {

            dto.setSchoolName(courseRepository.getSchoolNameFromDB(dto.getSchoolDataId()));
            dto.setSchoolLogo(courseRepository.getSchoolLogoFromDB(dto.getSchoolDataId()));
        }

        return result;
    }

    public List<CourseFeedbackDto> getAllCoursesBySchoolId(Long schoolId) {
        List<CourseFeedbackDto> result = new ArrayList<>(courseRepository.findCoursesBySchoolDataId(schoolId).stream()
                .map(CourseMapper.COURSE_MAPPER::mapToFeedbackDto)
                .toList());

        if (result.size() == 0) {
            result.add(new CourseFeedbackDto(null, "Отзыв по школе"));
            return result;
        }


        result.add(new CourseFeedbackDto(null, "Отзыв по школе"));

        return result;
    }

}

