package app.controller;

import app.dto.UserDto;
import app.model.User;
import app.service.UserService;
import app.util.validation.UserValidator;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.Optional;

@Controller
public class AuthController {
    public final UserService userService;
    public final UserValidator userValidator;


    @Autowired
    public AuthController(UserService userService,
                          UserValidator userValidator
    ) {
        this.userService = userService;
        this.userValidator = userValidator;
    }

    @GetMapping("/welcome")
    public ModelAndView welcomePage() throws UsernameNotFoundException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        try {

            Optional<User> user = userService.findByEmail(auth.getName());

            if (user.isEmpty()) throw new UsernameNotFoundException("Пользователь не найден");

            String name = (user.get().getFirstName() + " " + user.get().getLastName());

            ModelAndView welcome = new ModelAndView("welcome");
            welcome.addObject("name", name);

            return welcome;

        } catch (UsernameNotFoundException exception) {
            ModelAndView login = new ModelAndView("login");
            return login;
        }

    }


    @GetMapping("/login")
    public ModelAndView index() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication instanceof AnonymousAuthenticationToken) {
            ModelAndView login = new ModelAndView("login");
            return login;

        }
        ModelAndView welcome = new ModelAndView("welcome");
        return welcome;
    }

    @GetMapping("/registration")
    public ModelAndView registrationPage(@ModelAttribute("userDto") UserDto userDto) {
        ModelAndView modelAndView = new ModelAndView("registration");
        return modelAndView;
    }

    @PostMapping("/registration")
    public ModelAndView doRegistration(@ModelAttribute("userDto") @Valid UserDto userDto,
                                       BindingResult bindingResult) throws IOException {

        userValidator.validate(userDto, bindingResult);

        if (bindingResult.hasErrors()) {
            ModelAndView registration = new ModelAndView("registration");
            return registration;
        }

        userService.signUp(userDto);

        ModelAndView login = new ModelAndView("login");
        return login;
    }


}
