package app.controller;

import app.dto.categories.CategoriesDto;
import app.exception.EntityNotFoundException;
import app.exception.EntityNotFoundResponse;
import app.service.CategoriesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categories")
@CrossOrigin(origins = "https://edchart.ru")
public class CategoriesController {
    public final CategoriesService categoriesService;

    @Autowired
    public CategoriesController(CategoriesService categoriesService) {
        this.categoriesService = categoriesService;

    }

    @GetMapping("/all")
    public ResponseEntity<List<CategoriesDto>> getSubcategoriesAll() {
        return ResponseEntity.ok(categoriesService.findAll());

    }

    @GetMapping("/api/{categoryId}")
    public ResponseEntity<CategoriesDto> getSubcategoryById(
            @PathVariable(name = "categoryId", required = true) long categoryId) {
        return ResponseEntity.ok(categoriesService.findById(categoryId));
    }

    @GetMapping("/{categoryName}")
    public ResponseEntity<CategoriesDto> getSubcategoryByNativeName(
            @PathVariable(name = "categoryName", required = true) String categoryName) {
        return ResponseEntity.ok(categoriesService.findByCategoryNativeName(categoryName));
    }

    @ExceptionHandler
    public ResponseEntity<EntityNotFoundResponse> handleException(EntityNotFoundException ex) {
        EntityNotFoundResponse response = new EntityNotFoundResponse();
        response.setEntityName(ex.getEntityName());
        response.setEntityId(ex.getEntityId());
        response.setMessage(ex.getMessage());
        response.setStatus(HttpStatus.NOT_FOUND.value());
        response.setTimestamp(System.currentTimeMillis());
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }
}
