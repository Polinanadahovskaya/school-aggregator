package app.controller;

import app.dto.schooldata.SchoolDataWithCountFBsAndTypesFBsDto;
import app.dto.schooldata.SchoolDataWithCountFBsAndTypesFBsPagingDto;
import app.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/school-data")
@CrossOrigin(origins = "https://edchart.ru")
public class SchoolDataController {

    private final SchoolService schoolService;

    @Autowired
    public SchoolDataController(SchoolService schoolService) {
        this.schoolService = schoolService;
    }

//    @GetMapping("/getAll")
//        //special
//    List<SchoolDataWithCommentsDto> getListAllSchoolsWithComments() {
//        return schoolService.getAllSchoolsWithComments2();
//    }

//    @GetMapping("/get/{schoolName}")
//    SchoolDataWithCommentsDto getListAllSchoolsWithComments(@PathVariable(name = "schoolName") String schoolName
//    ) {
//        return schoolService.getSchoolByName2(schoolName);
//    }

    @GetMapping("/get/{schoolName}")
        //return one school with rating and counting types of fb
    SchoolDataWithCountFBsAndTypesFBsDto getSchool(@PathVariable(name = "schoolName") String schoolName) {
        return schoolService.getSchool(schoolName);
    }

    // -
    @GetMapping("/getRating")
        //return all schools with rating and counting types of fb
    List<SchoolDataWithCountFBsAndTypesFBsDto> getRatingAndCountFeedbacks() {
        return schoolService.getRatingsAndFeedBacksForAllSchools();
    }

    @GetMapping("/getRatingPortions")
        //return schools with rating and counting types of fb by portions with toplist rating DESC
    SchoolDataWithCountFBsAndTypesFBsPagingDto getRatingAndCountFeedbacks(
            @RequestParam(defaultValue = "0", name = "page") Integer page,
            @RequestParam(defaultValue = "5", name = "pageSize") Integer pageSize) {

        return schoolService.getRatingsByPortions(page, pageSize);
    }


}
