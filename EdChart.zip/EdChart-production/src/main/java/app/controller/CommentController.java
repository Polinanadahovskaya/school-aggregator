package app.controller;

import app.dto.comment.CommentDto;
import app.dto.comment.CommentDtoIncome;
import app.dto.comment.CommentPagingDto;
import app.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
@CrossOrigin(origins = "https://edchart.ru")
public class CommentController {

    public final CommentService commentService;

    @Autowired
    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }


    @GetMapping("/{schoolName}") //не используем больше - временное решение
    public List<CommentDto> getSchool10Comments(@PathVariable(name = "schoolName") String schoolNativeName) {

        return commentService.find10CommentsSchool(schoolNativeName);
    }

    @PostMapping("/post-comment")
    public CommentDto saveCommentFromUser(@RequestBody CommentDtoIncome commentDtoIncome) {
        System.out.println(commentDtoIncome);
        return commentService.saveComment(commentDtoIncome);
    }

    @GetMapping("/get-comments")
    public CommentPagingDto getAllCommentsByPageable(@RequestParam(name = "schoolId") Long schoolId,
                                                     @RequestParam(defaultValue ="0",name = "page") Integer page,
                                                     @RequestParam(defaultValue = "10", name = "pageSize") Integer pageSize){

        return commentService.processCommentsByPortions(schoolId,page,pageSize);
    }


}
