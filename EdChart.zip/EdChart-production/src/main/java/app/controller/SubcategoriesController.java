package app.controller;

import app.dto.subcategories.SubcategoriesWithCoursesDto;
import app.exception.EntityNotFoundException;
import app.exception.EntityNotFoundResponse;
import app.service.SubcategoriesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/subcategories")
@CrossOrigin(origins = "https://edchart.ru")
public class SubcategoriesController {

    private final SubcategoriesService subcategoriesService;

    @Autowired
    public SubcategoriesController(SubcategoriesService subcategoriesService) {
        this.subcategoriesService = subcategoriesService;
    }

    @GetMapping("/subcategory/api/{subcategoryId}")
    public ResponseEntity<SubcategoriesWithCoursesDto> findSubcategoryWithCourses(@PathVariable(name = "subcategoryId") long subcategoryId) {
        return ResponseEntity.ok(subcategoriesService.findSubcategoryWithCoursesById(subcategoryId));
    }

    @GetMapping("/subcategory/{subcategoryName}")
    public ResponseEntity<SubcategoriesWithCoursesDto> findSubcategoryWithCourses(@PathVariable(name = "subcategoryName") String subcategoryName) {
        return ResponseEntity.ok(subcategoriesService.findSubcategoryWithCoursesByName(subcategoryName));
    }

    @ExceptionHandler
    public ResponseEntity<EntityNotFoundResponse> handleException(EntityNotFoundException ex) {
        EntityNotFoundResponse response = new EntityNotFoundResponse();
        response.setEntityName(ex.getEntityName());
        response.setEntityId(ex.getEntityId());
        response.setMessage(ex.getMessage());
        response.setStatus(HttpStatus.NOT_FOUND.value());
        response.setTimestamp(System.currentTimeMillis());
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }

}
