package app.controller;

import app.dto.course.CourseDto;
import app.dto.course.CourseFeedbackDto;
import app.exception.EntityNotFoundException;
import app.exception.EntityNotFoundResponse;
import app.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
@CrossOrigin(origins = "https://edchart.ru")
public class CourseController {

    private final CourseService courseService;

    @Autowired
    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping("/all") //test delete for PROD
    public List<CourseDto> getCoursesAll() {
        return courseService.findAll().stream().toList();
    }

    @GetMapping("/api/{courseId}")
    public CourseDto getCourseById(@PathVariable(name = "courseId") long courseid) {
        return courseService.findById(courseid);
    }

    @GetMapping("/{courseName}")
    public CourseDto getCourseByNativeName(@PathVariable(name = "courseName") String courseName) {
        System.out.println("received coursename " + courseName);
        return courseService.findByNativeName(courseName);
    }

    @GetMapping("/random")
    public List<CourseDto> getRandom(
            @RequestParam(name = "schoolId", defaultValue = "0") Long schoolId,
            @RequestParam(name = "repeat") Long repeat) {
        return courseService.getRandom(schoolId, repeat);
    }

    @GetMapping("/get/{schoolId}")
    public List<CourseFeedbackDto> getAllCoursesBySchoolId(
            @PathVariable(name = "schoolId") Long schoolId) {
        return courseService.getAllCoursesBySchoolId(schoolId);
    }

    @ExceptionHandler
    public ResponseEntity<EntityNotFoundResponse> handleException(EntityNotFoundException ex) {
        EntityNotFoundResponse response = new EntityNotFoundResponse();
        response.setEntityName(ex.getEntityName());
        response.setEntityId(ex.getEntityId());
        response.setMessage(ex.getMessage());
        response.setStatus(HttpStatus.NOT_FOUND.value());
        response.setTimestamp(System.currentTimeMillis());
        return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
    }
}
