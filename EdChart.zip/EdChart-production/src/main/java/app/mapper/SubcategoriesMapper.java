package app.mapper;

import app.dto.subcategories.SubcategoriesDto;
import app.model.Subcategories;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface SubcategoriesMapper {

    SubcategoriesMapper SUBCATEGORIES_MAPPER = Mappers.getMapper(SubcategoriesMapper.class);

    Subcategories mapFromDto(SubcategoriesDto dto);

    SubcategoriesDto mapToDto(Subcategories entity);
}