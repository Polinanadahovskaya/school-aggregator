package app.mapper;

import app.dto.categories.CategoriesDto;
import app.model.Categories;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface CategoriesMapper {

    CategoriesMapper CATEGORIES_MAPPER = Mappers.getMapper(CategoriesMapper.class);

    Categories mapFromDto(CategoriesDto dto);

    CategoriesDto mapToDto(Categories entity);

}
