package app.mapper;


import app.dto.comment.CommentDto;
import app.dto.comment.CommentDtoIncome;
import app.model.Comment;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface CommentMapper {

    CommentMapper COMMENT_MAPPER = Mappers.getMapper(CommentMapper.class);

    Comment mapFromDto(CommentDto dto);

    //@Mapping(source = "date", target = "date", dateFormat = "dd.MM.yyyy")
    CommentDto mapToDto(Comment entity);

    CommentDto mapToDtoFromIncome(CommentDtoIncome commentDtoIncome);



}
