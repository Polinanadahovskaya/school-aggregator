package app.mapper;

import app.dto.subcategories.SubcategoriesWithCoursesDto;
import app.model.Subcategories;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel="spring")
public interface SubcategoriesWithCoursesMapper {

    SubcategoriesWithCoursesMapper SUBCATEGORIESWITHCOURSES_MAPPER = Mappers.getMapper(SubcategoriesWithCoursesMapper.class);

    Subcategories mapFromDto(SubcategoriesWithCoursesDto dto);

    SubcategoriesWithCoursesDto mapToDto(Subcategories entity);
}
