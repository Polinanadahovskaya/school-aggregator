package app.mapper;

import app.dto.schooldata.SchoolDataDto;
import app.dto.schooldata.SchoolDataRatingCountFeedbacksDto;
import app.dto.schooldata.SchoolDataWithCountFBsAndTypesFBsDto;
import app.model.SchoolData;
import app.model.sql.SqlCountRating;
import app.model.sql.SqlCountTypeFeedbacksSchoolData;
import app.model.sql.SqlSchoolDataTopList;
import app.repository.CommentRepository;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface SchoolDataMapper {
    SchoolDataMapper SCHOOL_DATA_MAPPER = Mappers.getMapper(SchoolDataMapper.class);


    SchoolDataDto mapToDto(SchoolData entity);

    // -
    //SchoolData mapToEntity(SchoolDataDto dto);

    // -
    SchoolDataWithCountFBsAndTypesFBsDto mapDtoToDto(SchoolDataDto dto);

    SchoolDataRatingCountFeedbacksDto mapDtoToDto2(SchoolDataDto dto);

   // preparing pagination with top list
    default SchoolDataWithCountFBsAndTypesFBsDto mapFromSqlToDto(SqlSchoolDataTopList entity, @Context CommentRepository commentRepository) {
        SchoolDataWithCountFBsAndTypesFBsDto result = new SchoolDataWithCountFBsAndTypesFBsDto();


        result.setId(entity.getId());
        result.setName(entity.getName());

        result.setNativeName(entity.getNativeName());
        result.setLogo(entity.getLogo());
        result.setDescription(entity.getDescription());
        result.setLink(entity.getLink());
        result.setRating(entity.getRating());
        result.setFeedbacks(0L);
        result.setPositiveFeedbacks(0);
        result.setNeutralFeedbacks(0);
        result.setNegativeFeedbacks(0);
        result.setToplist(0L);


        SqlCountTypeFeedbacksSchoolData countTypeFeedbacks = commentRepository.getCountTypeFeedbacks(entity.getId()); //getting counting types of feedbacks

        SqlCountRating countFeedbacksAndRating = commentRepository.getCountFeedbacksAndRating(entity.getId());

        if (countFeedbacksAndRating == null) { //у некоторых школ нет никаких данных
            return result;
        }

        //если данные по рейтингам и отзывам имеются то заполним их + toplist
        result.setFeedbacks(countFeedbacksAndRating.getCount());
        result.setPositiveFeedbacks(countTypeFeedbacks.getPositiveFeedbacks());
        result.setNeutralFeedbacks(countTypeFeedbacks.getNeutralFeedbacks());
        result.setNegativeFeedbacks(countTypeFeedbacks.getNegativeFeedbacks());
        result.setToplist(entity.getToplist());


        return result;
    }

    //just for 1 getSchool only
    default SchoolDataWithCountFBsAndTypesFBsDto mapToDtoWithAdditionalData(SchoolData entity, @Context CommentRepository commentRepository) {

        SchoolDataWithCountFBsAndTypesFBsDto result = mapDtoToDto(mapToDto(entity));
        //изначально делаем инициализацию с 0
        result.setFeedbacks(0L);
        result.setPositiveFeedbacks(0);
        result.setNeutralFeedbacks(0);
        result.setNegativeFeedbacks(0);

        SqlCountTypeFeedbacksSchoolData countTypeFeedbacks = commentRepository.getCountTypeFeedbacks(entity.getId()); //getting counting types of feedbacks

        SqlCountRating countFeedbacksAndRating = commentRepository.getCountFeedbacksAndRating(entity.getId());

        if (countFeedbacksAndRating == null) { //у некоторых школ нет никаких данных
            return result;
        }
        //если данные по рейтингам и отзывам имеются то заполним их
        result.setFeedbacks(countFeedbacksAndRating.getCount());
        result.setPositiveFeedbacks(countTypeFeedbacks.getPositiveFeedbacks());
        result.setNeutralFeedbacks(countTypeFeedbacks.getNeutralFeedbacks());
        result.setNegativeFeedbacks(countTypeFeedbacks.getNegativeFeedbacks());
        result.setToplist(1L);
        return result;

    }

    // -
    default SchoolDataRatingCountFeedbacksDto mapToDto(SchoolData entity, @Context CommentRepository commentRepository) {
        SchoolDataRatingCountFeedbacksDto result = mapDtoToDto2(mapToDto(entity));

        //изначально делаем инициализацию с 0
        result.setFeedbacks(0L);
        result.setPositiveFeedbacks(0);
        result.setNeutralFeedbacks(0);
        result.setNegativeFeedbacks(0);

        SqlCountTypeFeedbacksSchoolData countTypeFeedbacks = commentRepository.getCountTypeFeedbacks(entity.getId()); //getting counting types of feedbacks

        SqlCountRating countFeedbacksAndRating = commentRepository.getCountFeedbacksAndRating(entity.getId());

        if (countFeedbacksAndRating == null) { //у некоторых школ нет никаких данных
            return result;
        }

        //если данные по рейтингам и отзывам имеются, то заполним их
        result.setFeedbacks(countFeedbacksAndRating.getCount());
        result.setPositiveFeedbacks(countTypeFeedbacks.getPositiveFeedbacks());
        result.setNeutralFeedbacks(countTypeFeedbacks.getNeutralFeedbacks());
        result.setNegativeFeedbacks(countTypeFeedbacks.getNegativeFeedbacks());

        return result;
    }

}

