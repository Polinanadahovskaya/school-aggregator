package app.mapper;

import app.dto.course.CourseDto;
import app.dto.course.CourseFeedbackDto;
import app.model.Course;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel="spring")
public interface CourseMapper {

    CourseMapper COURSE_MAPPER = Mappers.getMapper(CourseMapper.class);

    Course mapFromDto(CourseDto dto);


    CourseDto mapToDto(Course entity);

    CourseFeedbackDto mapToFeedbackDto(Course entity);

}
