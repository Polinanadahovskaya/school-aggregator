package app.mapper;

import app.dto.comment.CommentDto;
import app.dto.schooldata.SchoolDataRatingCountFeedbacksDto;
import app.dto.schooldata.SchoolDataWithCommentsDto;
import app.model.SchoolData;
import app.model.sql.SqlCountRating;
import app.repository.CommentRepository;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Mapper(componentModel = "spring", uses = CommentRepository.class, injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public abstract class SchoolDataSpecialMapper {


    private CommentRepository commentRepository;

    @Autowired
    public void setCommentRepository(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }


    public SchoolDataWithCommentsDto mapToDto(SchoolData entity) {
        SchoolDataWithCommentsDto dto = new SchoolDataWithCommentsDto();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setNativeName(entity.getNativeName());
        dto.setLogo(entity.getLogo());
        dto.setDescription(entity.getDescription());
        dto.setLink(entity.getLink());
        dto.setRating(entity.getRating());

        //calculating rating, count of feedbacks
        SqlCountRating sqlQuery = commentRepository.getCountFeedbacksAndRating(entity.getId());

        if (sqlQuery == null) { //не у всех школ есть отзывы
            dto.setFeedbacks(0L);
        } else {
            dto.setFeedbacks(sqlQuery.getCount());
        }
        //receiving list of comments for school
        List<CommentDto> listCommentDto = commentRepository.findCommentBySchoolDataId(entity.getId()).stream()
                .map(CommentMapper.COMMENT_MAPPER::mapToDto)
                .toList();

        dto.setCommentDtoList(listCommentDto);

        return dto;
    }

    public List<SchoolDataRatingCountFeedbacksDto> mapListToDto(List<SchoolData> schoolDataList) {

        List<SchoolDataRatingCountFeedbacksDto> result = new ArrayList<>();
        for (SchoolData item : schoolDataList) {
            SchoolDataRatingCountFeedbacksDto dto = new SchoolDataRatingCountFeedbacksDto();
            dto.setId(item.getId());
            dto.setName(item.getName());
            dto.setNativeName(item.getNativeName());
            dto.setLogo(item.getLogo());
            dto.setDescription(item.getDescription());
            dto.setLink(item.getLink());
            dto.setRating(item.getRating());
            SqlCountRating sqlQuery = commentRepository.getCountFeedbacksAndRating(item.getId());//query
            if (sqlQuery == null) { //не у всех школ есть отзывы
                dto.setFeedbacks(0L);
            } else {
                dto.setFeedbacks(sqlQuery.getCount());
            }
            result.add(dto);
        }

        result.sort(Comparator.comparing(SchoolDataRatingCountFeedbacksDto::getRating).reversed());
        return result;
    }


}
