package app.mapper;

import app.dto.course.CourseDto;

import app.model.CourseData;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel="spring")
public interface CourseDataMapper {

    CourseDataMapper COURSEDATA_MAPPER = Mappers.getMapper(CourseDataMapper.class);

    CourseData mapFromDto(CourseDto dto);

    CourseDto mapToDto(CourseData entity);

}
