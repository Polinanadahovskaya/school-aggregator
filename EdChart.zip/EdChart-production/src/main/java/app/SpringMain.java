package app;

import app.service.SchoolService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.security.GeneralSecurityException;

@SpringBootApplication
public class SpringMain {
    public static void main(String[] args) throws GeneralSecurityException, IOException {
        ConfigurableApplicationContext context = SpringApplication.run(SpringMain.class, args);


        //parser Google Sheets
        //context.getBean(SchoolService.class).saveDataToDB(); //parsing schools in DB


        //написать обновление рейтингов каждые 5 минут! 19 01 2023

    }
}
