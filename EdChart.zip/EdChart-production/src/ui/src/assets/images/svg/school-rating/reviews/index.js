import negatives from './negatives.svg';
import neutral from './neutral.svg';
import positives from './positives.svg';

export { negatives, neutral, positives };
