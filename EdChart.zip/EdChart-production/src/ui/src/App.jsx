import { QueryClient, QueryClientProvider } from 'react-query';
import { ReactQueryDevtools } from 'react-query/devtools';
import { HelmetProvider } from 'react-helmet-async';
import {
  BrowserRouter,
  Routes,
  Route,
  Outlet,
  Navigate,
} from 'react-router-dom';
import Layout from './components/Layout';
import Main from './pages/Main/Main';
import Login from './pages/Login/Login';
import Register from './pages/Register/Register';
import School from './pages/School/School';
import Course from './pages/Course/Course';
import AllCourses from './pages/AllCourses/AllCourses';
import SchoolRating from './pages/SchoolRating/SchoolRating';

const queryClient = new QueryClient();

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Main />} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="rating">
          <Route index element={<SchoolRating />} />
          <Route path=":school" element={<School />} />
        </Route>
        <Route path="categories">
          <Route index element={<Navigate to="/" />} />
          <Route path=":category" element={<Outlet />}>
            <Route index element={<Navigate to="/" />} />
            <Route path=":course" element={<Course />} />
          </Route>
        </Route>
        <Route path="coursecare" element={<AllCourses />} />
      </Route>
    </Routes>
  );
};

const WrappedApp = () => {
  return (
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <HelmetProvider>
          <App />
        </HelmetProvider>
        <ReactQueryDevtools />
      </QueryClientProvider>
    </BrowserRouter>
  );
};

export default WrappedApp;
