import api from './apiInstance';

const getCatalog = async () => {
  const response = await api.get('categories/all');
  return response.data;
};

export default getCatalog;
