import api from './apiInstance';

const getSchoolRatingPaginated = async ({ pageParam = 0 }) => {
  const response = await api.get(
    `school-data/getRatingPortions?page=${pageParam} `
  );
  return response.data;
};

export default getSchoolRatingPaginated;
