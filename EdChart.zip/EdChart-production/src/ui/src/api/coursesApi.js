import api from './apiInstance';

const getRandomCourses = async () => {
  const response = await api.get('courses/random?repeat=3');
  return response.data;
};

export default getRandomCourses;
