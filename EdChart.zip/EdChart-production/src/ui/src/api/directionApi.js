import api from './apiInstance';

const getDirectionData = async (direction) => {
  const response = await api.get(`subcategories/subcategory/${direction}`);
  return response.data;
};

export default getDirectionData;
