import api from './apiInstance';

const getSchoolData = async (school) => {
  const response = await api.get(`school-data/get/${school}`);
  return response.data;
};

export const getBestCourses = async (id) => {
  const response = await api.get(`courses/random?&repeat=3&schoolId=${id}`);
  return response.data;
};

export default getSchoolData;
