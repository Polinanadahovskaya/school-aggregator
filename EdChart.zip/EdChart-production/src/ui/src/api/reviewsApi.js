import api from './apiInstance';

const getReviewsPaginated = async (school, pageParam) => {
  const response = await api.get(
    `comments/get-comments?schoolId=${school}&page=${pageParam}`
  );
  return response.data;
};

export default getReviewsPaginated;
