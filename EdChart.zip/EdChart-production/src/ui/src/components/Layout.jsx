import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Header from './layouts/Header';
import Footer from './layouts/Footer';

const Layout = () => {
  const catalogState = useState(false);

  return (
    <>
      <Header catalogState={catalogState} />
      <main className="main">
        <Outlet context={catalogState} />
      </main>
      <Footer />
    </>
  );
};

export default Layout;
