import { Modal, Box } from '@mui/material';
import Popapfb from './Popupfb';

const FeedbackModal = ({ open, handleClose, schoolId }) => {
  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
      sx={{
        '& > .MuiBackdrop-root': {
          backdropFilter: 'blur(7px)',
          width: '100vw',
        },
      }}
    >
      <Box>
        <Popapfb onClose={handleClose} schoolDataId={schoolId} />
      </Box>
    </Modal>
  );
};

export default FeedbackModal;
