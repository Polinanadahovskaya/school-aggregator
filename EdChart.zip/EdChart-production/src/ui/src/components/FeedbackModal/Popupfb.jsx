import { useState, useCallback, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';

import './popupfb.scss';
import Select from '@mui/material/Select';
import TextField from '@mui/material/TextField';
import Rating from '@mui/material/Rating';
import MenuItem from '@mui/material/MenuItem';

import { BASE_URL } from '../../api/apiInstance';

const Popapfb = ({ schoolDataId, onClose }) => {
  const [coursesData, setCoursesData] = useState(null);

  const getCoursesData = useCallback(async () => {
    const response = await fetch(`${BASE_URL}/courses/get/${schoolDataId}`);
    if (!response.ok) {
      throw new Error(response.status);
    }
    const course = await response.json();
    // console.log(course);
    setCoursesData(course);
  }, [schoolDataId]);

  useEffect(() => {
    getCoursesData();
  }, [getCoursesData]);

  const { register, handleSubmit, control } = useForm();
  const onSubmit = (data) => {
    const newData = {
      ...data,

      schoolDataId,
      nickname: null,
      userId: null,
    };
    // console.log(newData);
    fetch(`${BASE_URL}/comments/post-comment`, {
      method: 'POST',
      body: JSON.stringify(newData),
      headers: {
        'Content-Type': 'application/json',
      },
    }).then((res) => {
      res.json();
      onClose();
    });
  };

  return (
    <form className="popapfb" onSubmit={handleSubmit(onSubmit)}>
      <h3 className="namepopap">Оставьте отзыв!</h3>
      <Controller
        name="score"
        control={control}
        defaultValue={0}
        render={({ field }) => (
          <Rating
            {...field}
            className="school-reiting-namecompany"
            precision={0.1}
            size="large"
            sx={{ fontSize: '50px' }}
            {...field}
            onChange={(_, value) => field.onChange(value)}
          />
        )}
      />

      {coursesData && (
        <div className="input-popap">
          <Controller
            name="courseId"
            control={control}
            defaultValue={null}
            render={({ field }) => (
              <Select
                {...field}
                sx={{
                  '.MuiSelect-select': {
                    width: '29vw',
                  },
                  '.MuiOutlinedInput-notchedOutline': {
                    border: 'none',
                  },
                }}
                options={coursesData}
              >
                {coursesData.map((options) => {
                  return (
                    <MenuItem value={options.id} key={options.id}>
                      {options.name}
                    </MenuItem>
                  );
                })}
              </Select>
            )}
          />
        </div>
      )}

      <input
        type="text"
        id="title"
        placeholder="Заголовок"
        className="input-popap"
        {...register('title')}
      />

      <Controller
        name="content"
        defaultValue=""
        control={control}
        render={({ field }) => (
          <TextField
            sx={{
              '.MuiInputBase-input': {
                width: '87%',
              },
              '.MuiOutlinedInput-root': {
                border: '1px solid',
                borderColor: '#a3acff',
                width: '100%',
              },
              '.MuiOutlinedInput-notchedOutline': {
                border: 'none',
              },
            }}
            multiline
            rows={6}
            {...field}
            className="textarea-popap"
          />
        )}
      />
      <button type="submit" className="button-poparea">
        Оставить отзыв
      </button>
    </form>
  );
};
export default Popapfb;
