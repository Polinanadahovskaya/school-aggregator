import { Rating } from '@mui/material';

import './review.scss';

const Review = (props) => {
  const { score, date, nickname, title, content } = props;

  const getRatingColor = (ratingValue) => {
    if (ratingValue < 2.5) return 'red';
    if (ratingValue <= 3.8) return 'yellow';
    return 'green';
  };

  return (
    <article className="review">
      <div className="review_info">
        <div className="review_rating">
          <Rating value={score} precision={0.1} readOnly size="large" />
          <span className={`review_rating_value ${getRatingColor(score)}`}>
            {score}
          </span>
        </div>
        <div className="review_credentials">
          <span className="credentials_date">{date}</span>
          <span className="credentials_name">{nickname}</span>
        </div>
      </div>
      <h1 className="review_title">{title}</h1>
      <p className="review_text">{content}</p>
      <div className="review_controls" />
    </article>
  );
};

export default Review;
