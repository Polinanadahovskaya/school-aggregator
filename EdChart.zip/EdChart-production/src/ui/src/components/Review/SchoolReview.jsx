import { Rating } from '@mui/material';

import './SchoolReview.scss';

const SchoolReview = (props) => {
  const { logo, rating, feedbacks, placement, description, nativeName } = props;

  return (
    <article className="school-review">
      <div className="school-review_header">
        <div className="placement-logo">
          <span className="rating-place">{placement}</span>
          <img src={logo} alt="Логотип школы" className="school-logo" />
        </div>
        <div className="school-review_rating-stars">
          <span className="rating-value">{rating}</span>
          <Rating value={rating} precision={0.1} readOnly size="large" />
          <a href={`/rating/${nativeName}`} className="school-review_link">
            отзывов: {feedbacks}
          </a>
        </div>
      </div>
      <p className="school-review_content">{description}</p>
    </article>
  );
};

export default SchoolReview;
