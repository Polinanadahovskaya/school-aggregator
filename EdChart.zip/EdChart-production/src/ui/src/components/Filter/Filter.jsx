import './filter.scss';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import React from 'react';

const Filter = ({ namecoursefilter, nameplatform }) => {
  return (
    <div className="div-for-filter">
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Уровень сложности</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                Продвинутый
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                Начинающий
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Цена</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox" />
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Тип обучения</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                Вебинар
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                Курс
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Формат обучения</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                Записанные лекции
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                С проверкой домашнего задания
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Длительность курса</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                1-3 месяца
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                12 месяцев и более
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Онлайн платформы</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                {nameplatform}
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                {nameplatform}
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">Разработчик курса</div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                {namecoursefilter}
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                {namecoursefilter}
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <div className="name-for-filter-in-accardion">
            Гарантия трудоустройства
          </div>
        </AccordionSummary>
        <AccordionDetails>
          <div className="flex-checkbox">
            <div>
              <input
                type="checkbox"
                id="coding"
                name="interest"
                value="midl"
                className="checkbox"
              />
              <label htmlFor="midl" className="checkbox-name">
                Гарантия
              </label>
            </div>
            <div>
              <input
                type="checkbox"
                id="music"
                name="interest"
                value="junior"
                className="checkbox"
              />
              <label htmlFor="junior" className="checkbox-name">
                Отсутствует
              </label>
            </div>
          </div>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};
export default Filter;
