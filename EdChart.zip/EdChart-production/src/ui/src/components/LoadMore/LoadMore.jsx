import './loadmore.scss';

const LoadMore = ({
  hasNextPage,
  fetchNextPage,
  isFetchingNextPage,
  openModal,
}) => {
  const button = (
    <div className="div-loadore">
      <button
        className="loadMore-button"
        type="button"
        onClick={hasNextPage ? fetchNextPage : openModal}
        disabled={isFetchingNextPage}
      >
        {isFetchingNextPage && 'Загрузка...'}
        {!isFetchingNextPage && hasNextPage && 'Загрузить еще'}
        {!hasNextPage && 'Оставить отзыв'}
      </button>
    </div>
  );

  return (
    <div className="div-loadore">
      {button}
      {!hasNextPage && (
        <p className="loadMore-div">
          На этом всё! А теперь ты можешь оставь свой отзыв
        </p>
      )}
    </div>
  );
};

export default LoadMore;
