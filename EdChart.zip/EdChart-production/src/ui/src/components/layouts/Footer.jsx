import './footer.scss';

const Footer = () => {
  return <footer className="footer" />;
};

export default Footer;
