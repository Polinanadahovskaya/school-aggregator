import { useRef } from 'react';
import { Link } from 'react-router-dom';
import MobileNav from '../MobileNav/MobileNav';

// styles
import cx from './header.module.scss';

// assets
import profileLogo from '../../assets/images/svg/Profile.svg';
import searchSvg from '../../assets/images/svg/Lupa.svg';

// components
import Catalog from '../Catalog/Catalog';

const Header = ({ catalogState }) => {
  const [isOpen, setIsOpen] = catalogState;
  const nodeRef = useRef(null);
  const catalogBtnRef = useRef(null);

  const toggleCatalog = () => {
    setIsOpen(!isOpen);
  };

  const closeCatalog = (e) => {
    if (e.target === catalogBtnRef.current) return;
    if (nodeRef.current && !nodeRef.current.contains(e.target)) {
      setIsOpen(false);
    }
  };

  document.addEventListener('mousedown', closeCatalog);

  return (
    <>
      <header className={cx.header}>
        <div className={cx['header-inner']}>
          <div className={cx.nav}>
            <Link to="/" className={cx.logo}>
              EDCHART
            </Link>
            <div className={cx.controls}>
              <button
                type="button"
                className={cx['primary-btn']}
                onClick={toggleCatalog}
                ref={catalogBtnRef}
              >
                Каталог курсов
              </button>
              <Link to="/rating" className={cx['primary-btn']}>
                Рейтинг
              </Link>
              <button type="button" className={cx['primary-btn']}>
                Сравни
              </button>
            </div>
            <div className={cx['search-bar']}>
              <input
                type="text"
                className={cx['search-input']}
                placeholder="Найти..."
                aria-label="search"
              />
              <button
                type="button"
                aria-label="submit search"
                className={cx['search-btn']}
              >
                <img
                  src={searchSvg}
                  alt="Иконка поиска"
                  className={cx['search-icon']}
                />
              </button>
            </div>
            <Link to="/" className={cx['primary-btn']}>
              Блог
            </Link>
            <button type="button" className={cx['like-btn']}>
              {}
            </button>
            <Link to="/login" type="button" className={cx['profile-btn']}>
              <img src={profileLogo} alt="Иконка профиля" />
            </Link>
            <MobileNav openCatalog={setIsOpen} />
          </div>
        </div>
      </header>
      <div className={cx['catalog-container']} ref={nodeRef}>
        <Catalog isOpen={isOpen} />
      </div>
    </>
  );
};

export default Header;
