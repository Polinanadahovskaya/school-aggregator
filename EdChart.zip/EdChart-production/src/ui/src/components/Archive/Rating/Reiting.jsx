import './reiting.scss';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';

const Reiting = () => {
  return (
    <>
      <div className="feedback-name">
        <div className="name-page">
          <h2 className="h2-feedback">Рейтинг школ</h2>
          <p className="text-feedback">
            Здесь вы можете ознакомиться с рейтингом школ
          </p>
        </div>
      </div>
      <div className="conteiner-grid">
        <div className="grid-feedback">
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.5}
                    sx={{
                      '.MuiRating-label': {
                        color: 'blue',
                        fontSize: '12px',
                      },
                    }}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <div className="feedback-text">
              <h3 className="h3-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h3>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
        </div>
      </div>
    </>
  );
};
export default Reiting;
