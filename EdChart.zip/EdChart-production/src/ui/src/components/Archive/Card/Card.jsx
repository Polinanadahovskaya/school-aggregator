import { Link } from 'react-router-dom';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import python from '../../assets/images/svg/python.svg';
import './card.scss';

const Card = () => {
  return (
    <div className="card-component">
      <div className="cardname">
        <div className="namecourse">
          <h6 className="h6-slider">Образовательная платформа</h6>
          <h2 className="course">SKILLBOX</h2>
        </div>
        <div className="reiting">
          <p className="text-reiting">Рейтинг</p>
          <Stack spacing={1}>
            <Rating
              className="starrating"
              name="half-rating"
              defaultValue={2.5}
              precision={0.5}
            />
          </Stack>
        </div>
      </div>
      <div className="name_price">
        <div className="name_course">
          <h6 className="h6-slider">Курс</h6>
          <h4 className="h4-slider">Python-разработчик</h4>
        </div>
        <div className="price_cource">
          <h6 className="h6-slider">Стоимость курса</h6>
          <h4 className="h4-slider">120 000₽</h4>
        </div>
      </div>
      <div className="button-img">
        <Link className="aboutbutton" to="/">
          Подробнее
        </Link>
        <img
          src={python}
          alt="изображение для курса по питону"
          className="pyton-img"
        />
      </div>
    </div>
  );
};
export default Card;
