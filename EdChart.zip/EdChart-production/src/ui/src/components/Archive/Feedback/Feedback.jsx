import './feedback.scss';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import { Link } from 'react-router-dom';
import Namepeople from '../assets/images/svg/Namepeople.svg';
import Skillbox from '../assets/images/png/Skillbox.png';

const Feedback = () => {
  return (
    <div className="div-feedback">
      <div className="feedback-name">
        <div className="name-page">
          <h2 className="h2-feedback">Отзывы о курсах и онлайн-школах</h2>
          <p className="text-feedback">
            Отзывы с разных ресурсов по платформам, преподавателям, курсам
          </p>
        </div>
      </div>
      <div className="about-course-logo">
        <img src={Skillbox} alt="Иконка курса" className="iconka-course" />
        <Link to="/" className="link-course-logo">
          SKILLBOX
        </Link>
        <Stack spacing={1}>
          <Rating
            className="starrating"
            name="half-rating"
            defaultValue={5}
            precision={0.1}
          />
        </Stack>
      </div>
      <div className="conteiner-grid">
        <div className="grid-feedback">
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <img
                src={Namepeople}
                alt="Иконка имени человека оставившего отзыв"
                className="img-people-feedback"
              />
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.5}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <div className="feedback-text">
              <h3 className="h3-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h3>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <img
                src={Namepeople}
                alt="Иконка имени человека оставившего отзыв"
                className="img-people-feedback"
              />
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.1}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <Link to="/" className="link-to-course">
              Графический дизайн
            </Link>
            <div className="feedback-text">
              <h2 className="h2-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h2>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <img
                src={Namepeople}
                alt="Иконка имени человека оставившего отзыв"
                className="img-people-feedback"
              />
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.5}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <div className="feedback-text">
              <h3 className="h3-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h3>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <img
                src={Namepeople}
                alt="Иконка имени человека оставившего отзыв"
                className="img-people-feedback"
              />
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.5}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <div className="feedback-text">
              <h3 className="h3-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h3>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <img
                src={Namepeople}
                alt="Иконка имени человека оставившего отзыв"
                className="img-people-feedback"
              />
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.5}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <div className="feedback-text">
              <h3 className="h3-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h3>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
          <div className="feedback-people-card">
            <div className="peple-feedback-name">
              <img
                src={Namepeople}
                alt="Иконка имени человека оставившего отзыв"
                className="img-people-feedback"
              />
              <div className="people-name">
                <h3 className="h3-feedback">Ivan</h3>
                <Stack spacing={1}>
                  <Rating
                    className="starrating"
                    name="half-rating"
                    defaultValue={5}
                    precision={0.5}
                  />
                </Stack>
              </div>
              <p className="date-feedback">20.20.2020</p>
            </div>
            <div className="feedback-text">
              <h3 className="h3-feedback zagolovok">
                Тренирует мозги, расширяет кругозор, новый заработок
              </h3>
              <p className="feedback-otziv">
                Достоинства: приобретение новых знаний Недостатки: не увидела
                Очень довольна курсом. Грамотная и увлекательная подача
                материала, отзывчивые преподаватели, удобная платформа для
                обучения ( в любое удобное время, из любого уголка мира)....
              </p>
            </div>
            <h4 className="h4-school-name">SKILLBOX</h4>
            <div className="mark-hand" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Feedback;
