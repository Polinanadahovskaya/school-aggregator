import { useState } from 'react';
import { useQuery } from 'react-query';
import cn from 'classnames';
import { motion, AnimatePresence } from 'framer-motion';
import getCatalog from '../../api/catalogApi';

import './catalog.scss';

const Catalog = ({ isOpen }) => {
  const [currentCategory, setCurrentCategory] = useState(0);

  const {
    data: catalogData,
    error,
    isLoading,
  } = useQuery('catalogData', getCatalog);

  const handleCategory = (e) => {
    setCurrentCategory(+e.target.dataset.index);
  };

  if (error || isLoading) {
    return null;
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="box"
          className="catalog"
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          transition={{ duration: 0.3 }}
          exit={{ height: 0, opacity: 0 }}
        >
          <div className="catalog_categories">
            <ul className="categories_list">
              {catalogData.map(({ name, id }, index) => {
                return (
                  <li
                    key={id}
                    className={cn({
                      category: 'category',
                      active: currentCategory === +index,
                    })}
                  >
                    <button
                      type="button"
                      onClick={handleCategory}
                      onMouseEnter={handleCategory}
                      data-index={index}
                    >
                      {name}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
          <div className="subcategories">
            <ul className="subcategories_list">
              {catalogData[currentCategory].subcategoriesList.map(
                ({ id, nativeName, name }) => {
                  return (
                    <li key={id}>
                      <a
                        href={`/categories/${catalogData[currentCategory].nativeName}/${nativeName}`}
                      >
                        {name}
                      </a>
                    </li>
                  );
                }
              )}
            </ul>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Catalog;
