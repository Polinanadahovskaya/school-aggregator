import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import './card.scss';

const Cardwhitoutborder = ({
  name,
  link,
  logo,
  schoolLogo,
  price,
  rating,
  description,
}) => {
  return (
    <div className="card-whithout-border">
      <img
        src={logo}
        alt="Иконка изображения курса"
        className="img-card-bord"
      />
      <div className="card-info">
        <div className="name-and-price">
          <div className="name-and-reiting">
            {schoolLogo && (
              <img
                className="logo-reiting-namecompany"
                src={schoolLogo}
                alt="логотип компании"
              />
            )}
            <div className="ratnum">
              <Stack spacing={1}>
                <Rating
                  className="starrating-reiting-namecompany"
                  name="half-rating"
                  defaultValue={rating}
                  precision={0.1}
                  readOnly
                />
              </Stack>
              <p className="rating-number">{rating}</p>
            </div>
          </div>

          <div className="price-cource-bord">
            <h4 className="h4-about-course-card-price">{price} ₽</h4>
          </div>
        </div>
        <div className="about-course-card-bord">
          <h4 className="h4-about-course-card-bord">{name}</h4>
          <p className="p-about-course-card-bord">{description}</p>
          <a href={link} className="link-about-course-card-bord">
            Подробнее
          </a>
        </div>
      </div>
    </div>
  );
};

export default Cardwhitoutborder;
