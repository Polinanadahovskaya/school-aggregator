import { useState } from 'react';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import { ClickAwayListener } from '@mui/material';
import classes from './mobile-nav.module.scss';
import NavLinks from './NavLinks';

const MobileNav = ({ openCatalog }) => {
  const [isOpen, setIsOpen] = useState(false);

  const closeMenu = () => {
    setIsOpen(false);
  };

  return (
    <ClickAwayListener onClickAway={closeMenu}>
      <nav className={classes.mobileNav}>
        {isOpen ? (
          <CloseIcon
            className={classes.icon}
            sx={{ fontSize: 40 }}
            onClick={() => setIsOpen(!isOpen)}
          />
        ) : (
          <MenuIcon
            className={classes.icon}
            sx={{ fontSize: 40 }}
            onClick={() => setIsOpen(!isOpen)}
          />
        )}

        {isOpen && <NavLinks close={closeMenu} openCatalog={openCatalog} />}
      </nav>
    </ClickAwayListener>
  );
};

export default MobileNav;
