import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

import './nav-links.scss';

const NavLinks = ({ close, openCatalog }) => {
  const handleCatalog = () => {
    close();
    openCatalog(true);
  };

  return (
    <AnimatePresence>
      <motion.ul
        className="navlinks"
        key="box"
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: 'auto', opacity: 1 }}
        transition={{ duration: 0.3 }}
        exit={{ height: 0, opacity: 0 }}
      >
        <li className="navlink">
          <Link to="/rating" onClick={close}>
            Рейтинг
          </Link>
        </li>
        <li className="navlink">
          <Link to="/" onClick={close}>
            Блог
          </Link>
        </li>
        <li className="navlink">
          <Link to="/" onClick={close}>
            Сравнение
          </Link>
        </li>
        <li className="navlink">
          <button type="button" to="/categories" onClick={handleCatalog}>
            Каталог
          </button>
        </li>
      </motion.ul>
    </AnimatePresence>
  );
};
export default NavLinks;
