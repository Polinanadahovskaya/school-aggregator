// import { useState } from 'react';
import { LinearProgress } from '@mui/material';
import { Helmet } from 'react-helmet-async';
import { useInfiniteQuery } from 'react-query';
import getSchoolRatingPaginated from '../../api/scoolRatingApi';
import SchoolReview from '../../components/Review/SchoolReview';
import LoadMore from '../../components/LoadMore/LoadMore';

import './schoolRating.scss';

const SchoolRating = () => {
  // searchbar thingy
  // const [searchText, setSearchText] = useState('');

  // const handleSearchChange = (e) => {
  //   setSearchText(e.target.value);
  // };

  const {
    data: schoolRating,
    isLoading: isSchoolRatingLoading,
    error: schoolRatingError,
    hasNextPage,
    fetchNextPage,
    isFetchingNextPage,
  } = useInfiniteQuery({
    queryKey: 'schoolRatingDataPaginated',
    queryFn: getSchoolRatingPaginated,
    getNextPageParam: (lastPage, pages) => {
      if (lastPage.hasNext) {
        return pages.length + 1;
      }
      return undefined;
    },
  });

  if (isSchoolRatingLoading) return <LinearProgress />;

  if (schoolRatingError)
    return (
      <p style={{ margin: '50px' }}>
        Произошла ошибка при загрузке рейтинга школ
      </p>
    );

  const schoolRatingData = schoolRating.pages.map((page) => {
    return page.schoolDataWithCountFBsAndTypesFBsDtoList.map((rating) => (
      <SchoolReview key={rating.id} {...rating} />
    ));
  });

  return (
    <div className="schoolrating-container">
      <Helmet>
        <title>Рейтинг</title>
      </Helmet>
      <div className="school-rating-header">
        <h1 className="school-rating-header_title">Рейтинг школ EDCHAT</h1>
        <p className="school-rating-header_description">
          EdChart — это умный агрегатор образовательных курсов, основанный на
          интеллектуальном анализе запросов пользователей. Сервис позволяет
          выбрать обучение на основе инновационного метода объективной оценки
          курсов в области IT. Разработанная система выстраивает рейтинг в
          соответствии с оценкой большого количества качественных и
          количественных параметров и характеристик. Более того, применяется
          уникальный принцип коллаборативной фильтрации, позволяющий
          сформировать персонализированный рейтинг для каждого пользователя.
        </p>
        {/* commented searchbar */}
        {/* <input
          type="text"
          className="school-rating-header_search"
          value={searchText}
          onChange={handleSearchChange}
          placeholder="Поиск"
        /> */}
      </div>
      <section className="schoolrating-reviews">
        {schoolRatingData}
        {schoolRating?.pages?.length && (
          <LoadMore
            hasNextPage={hasNextPage}
            fetchNextPage={fetchNextPage}
            isFetchingNextPage={isFetchingNextPage}
          />
        )}
      </section>
    </div>
  );
};

export default SchoolRating;
