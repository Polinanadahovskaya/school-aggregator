/* eslint-disable no-console */
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';

import '../../styles/layouts/login-register.scss';

const Login = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) => console.log(data);

  return (
    <>
      <Link to="/" className="form-button" style={{ marginTop: '20px' }}>
        На главную
      </Link>
      <div className="form-container">
        <form className="form login-form" onSubmit={handleSubmit(onSubmit)}>
          <h1>Вход</h1>
          <div className="input-container">
            <input
              type="text"
              id="email"
              required
              {...register('email', { required: true })}
            />
            <label htmlFor="email">E-Mail</label>
            <div className="error">{errors?.email?.message}</div>
          </div>
          <div className="input-container">
            <input
              type="password"
              id="password"
              required
              {...register('password', { required: true })}
            />
            <label htmlFor="password">Пароль</label>
            <div className="error">{errors?.password?.message}</div>
          </div>
          <button type="submit" to="../coursepage" className="form-button">
            Вход
          </button>
          <Link to="/register" className="form-link">
            Еще не зарегистрированы?
            <span className="form-link_text">Регистрация</span>
          </Link>
        </form>
      </div>
    </>
  );
};

export default Login;
