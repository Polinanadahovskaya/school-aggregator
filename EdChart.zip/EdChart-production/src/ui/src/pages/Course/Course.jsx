import { useParams } from 'react-router-dom';
import { useQuery } from 'react-query';
import { LinearProgress } from '@mui/material';
import './course.scss';
import Card from '../../components/Card/Card';
import Filter from '../../components/Filter/Filter';
import getDirectionData from '../../api/directionApi';

const accordionData = [
  {
    namecoursefilter: 'Skillbox',
    nameplatform: 'Skillbox',
    id: 1,
  },
];

const Course = () => {
  const { course: courseName } = useParams();
  const {
    data: directionData,
    error,
    isLoading,
  } = useQuery(['directionData', courseName], () =>
    getDirectionData(courseName)
  );

  if (error) return null;

  if (isLoading) {
    return <LinearProgress />;
  }

  const hasCourses = !!directionData.coursesSet.length;

  const coursesData = hasCourses
    ? directionData.coursesSet.map((course) => {
        return <Card {...course} key={course.id} />;
      })
    : null;

  return (
    <div className="div-for-course">
      {directionData && (
        <div className="about-for-course">
          <h2 className="h2-for-course">{directionData.name}</h2>
          <p className="p-for-course">{directionData.description}</p>
          <p className="p1-for-course">
            Найдено курсов: {directionData.coursesSet.length || 0}
          </p>
        </div>
      )}
      {hasCourses && (
        <div className="filter-and-course">
          <Filter {...accordionData[0]} />
          <div className="grig-for-course">{coursesData}</div>
        </div>
      )}
    </div>
  );
};

export default Course;
