import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';

import '../../styles/layouts/login-register.scss';

const Register = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) => console.log(data);

  return (
    <>
      <Link to="/" className="form-button" style={{ marginTop: '20px' }}>
        На главную
      </Link>
      <div className="form-container">
        <form className="form login-form" onSubmit={handleSubmit(onSubmit)}>
          <h1>Регистрация</h1>
          <div className="input-container">
            <input
              type="text"
              id="firstName"
              name="firstName"
              required
              {...register('firstname', { required: true })}
            />
            <label htmlFor="firstName">Имя</label>
            <div className="error">{errors?.email?.message}</div>
          </div>
          <div className="input-container">
            <input
              type="text"
              id="lastName"
              name="lastName"
              required
              {...register('lastName', { required: true })}
            />
            <label htmlFor="lastName">Фамилия</label>
            <div className="error">{errors?.password?.message}</div>
          </div>
          <div className="input-container">
            <input
              type="text"
              id="email"
              name="email"
              required
              {...register('email', { required: true })}
            />
            <label htmlFor="email">E-Mail</label>
            <div className="error">{errors?.email?.message}</div>
          </div>
          <div className="input-container">
            <input
              type="tel"
              id="phone"
              name="phone"
              required
              {...register('phone', { required: true })}
            />
            <label htmlFor="phone">Телефон</label>
            <div className="error">{errors?.email?.message}</div>
          </div>
          <div className="input-container">
            <input
              type="password"
              id="password"
              name="password"
              required
              {...register('password', { required: true })}
            />
            <label htmlFor="password">Пароль</label>
            <div className="error">{errors?.password?.message}</div>
          </div>
          <div className="input-container">
            <input
              type="password"
              id="passwordConfirm"
              name="passwordConfirm"
              required
              {...register('passwordConfirm', { required: true })}
            />
            <label htmlFor="passwordConfirm">Введите пароль еще раз</label>
            <div className="error">{errors?.passwordConfirm?.message}</div>
          </div>
          <button type="submit" to="../coursepage" className="form-button">
            Вход
          </button>
          <Link to="/login" className="form-link">
            Уже есть учетная запись? <br />
            <span className="form-link_text">Вход</span>
          </Link>
        </form>
      </div>
    </>
  );
};

export default Register;
