import { Swiper, SwiperSlide } from 'swiper/react';
import Rating from '@mui/material/Rating';
import Stack from '@mui/material/Stack';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import './slider.scss';

import { Pagination, Navigation, EffectFade } from 'swiper';
import { Link } from 'react-router-dom';
import python from '../../assets/images/svg/python.svg';

const Slider = () => {
  return (
    <div className="slider">
      <h2 className="h2">Самые популярные курсы</h2>
      <Swiper
        slidesPerView={3}
        spaceBetween={10}
        slidesPerGroup={3}
        speed={800}
        loop="true"
        loopFillGroupWithBlank
        pagination={{
          clickable: true,
        }}
        navigation
        effect
        modules={[Pagination, Navigation, EffectFade]}
        className="mySwiper"
      >
        <SwiperSlide className="slider-card skillbox">
          <div className="cardname">
            <div className="namecourse">
              <h6 className="h6-slider">Образовательная платформа</h6>
              <h2 className="course">SKILLBOX</h2>
            </div>
            <div className="reiting">
              <p className="text-reiting">Рейтинг</p>
              <Stack spacing={1}>
                <Rating
                  className="starrating"
                  name="half-rating"
                  defaultValue={2.5}
                  precision={0.5}
                  sx={{
                    '.MuiRating-label': {
                      color: 'white',
                      fontSize: '12px',
                    },
                  }}
                  readOnly
                />
              </Stack>
            </div>
          </div>
          <div className="name_price">
            <div className="name_course">
              <h6 className="h6-slider">Курс</h6>
              <h4 className="h4-slider">Python-разработчик</h4>
            </div>
            <div className="price_cource">
              <h6 className="h6-slider">Стоимость курса</h6>
              <h4 className="h4-slider">120 000₽</h4>
            </div>
          </div>
          <div className="button-img">
            <Link className="aboutbutton" to="/">
              Подробнее
            </Link>
            <img
              src={python}
              alt="изображение для курса по питону"
              className="pyton-img"
            />
          </div>
        </SwiperSlide>
        <SwiperSlide className="slider-card skillbox">
          <div className="cardname">
            <div className="namecourse">
              <h6 className="h6-slider">Образовательная платформа</h6>
              <h2 className="course">SKILLBOX</h2>
            </div>
            <div className="reiting">
              <p className="text-reiting">Рейтинг</p>
              <Stack spacing={1}>
                <Rating
                  className="starrating"
                  name="half-rating"
                  defaultValue={2.5}
                  precision={0.5}
                  sx={{
                    '.MuiRating-label': {
                      color: 'white',
                      fontSize: '12px',
                    },
                  }}
                  readOnly
                />
              </Stack>
            </div>
          </div>
          <div className="name_price">
            <div className="name_course">
              <h6 className="h6-slider">Курс</h6>
              <h4 className="h4-slider">Python-разработчик</h4>
            </div>
            <div className="price_cource">
              <h6 className="h6-slider">Стоимость курса</h6>
              <h4 className="h4-slider">120 000₽</h4>
            </div>
          </div>
          <div className="button-img">
            <Link className="aboutbutton" to="/">
              Подробнее
            </Link>
            <img
              src={python}
              alt="изображение для курса по питону"
              className="pyton-img"
            />
          </div>
        </SwiperSlide>
        <SwiperSlide className="slider-card skillbox">
          <div className="cardname">
            <div className="namecourse">
              <h6 className="h6-slider">Образовательная платформа</h6>
              <h2 className="course">SKILLBOX</h2>
            </div>
            <div className="reiting">
              <p className="text-reiting">Рейтинг</p>
              <Stack spacing={1}>
                <Rating
                  className="starrating"
                  name="half-rating"
                  defaultValue={2.5}
                  precision={0.5}
                  sx={{
                    '.MuiRating-label': {
                      color: 'white',
                      fontSize: '12px',
                    },
                  }}
                  readOnly
                />
              </Stack>
            </div>
          </div>
          <div className="name_price">
            <div className="name_course">
              <h6 className="h6-slider">Курс</h6>
              <h4 className="h4-slider">Python-разработчик</h4>
            </div>
            <div className="price_cource">
              <h6 className="h6-slider">Стоимость курса</h6>
              <h4 className="h4-slider">120 000₽</h4>
            </div>
          </div>
          <div className="button-img">
            <Link className="aboutbutton" to="/">
              Подробнее
            </Link>
            <img
              src={python}
              alt="изображение для курса по питону"
              className="pyton-img"
            />
          </div>
        </SwiperSlide>
      </Swiper>
    </div>
  );
};

export default Slider;
