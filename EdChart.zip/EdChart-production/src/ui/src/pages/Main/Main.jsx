import { useOutletContext } from 'react-router-dom';
import { useQuery } from 'react-query';
import { Helmet } from 'react-helmet-async';
import getRandomCourses from '../../api/coursesApi';
import Grid from './Grid';
import Description from './Description';
import Slider from '../../components/Slider/Slider';
import Card from '../../components/Card/Card';

const Main = () => {
  const catalogState = useOutletContext();

  const {
    data: sliderData,
    error: sliderDataError,
    isLoading: sliderDataLoading,
  } = useQuery('randomCourses', getRandomCourses, {
    refetchOnWindowFocus: false,
  });

  if (sliderDataError || sliderDataLoading) {
    return null;
  }

  return (
    <div className="main-page-container">
      <Helmet>
        <title>Edchart</title>
      </Helmet>
      <Description catalogState={catalogState} />
      <Grid />
      <Slider>
        {sliderData.map((sliderCard) => (
          <Card key={sliderCard.id} {...sliderCard} />
        ))}
      </Slider>
    </div>
  );
};

export default Main;
