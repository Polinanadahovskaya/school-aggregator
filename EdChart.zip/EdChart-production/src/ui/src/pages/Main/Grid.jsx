import { useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';

import './grid.scss';
import Programm from '@images/svg/Programm.svg';
import Marketing from '@images/svg/Marketing.svg';
import AnalyticsLogo from '@images/svg/AnalytycsLogo.svg';
import Design from '@images/svg/Design.svg';
import Accounting from '@images/svg/Accounting.svg';
import Webcontent from '@images/svg/Webcontent.svg';
import Psychology from '@images/svg/Psychology.svg';
import Management from '@images/svg/Management.svg';

const Grid = () => {
  const [catalogIsOpen, setCatalogIsOpen] = useOutletContext();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
  }, [catalogIsOpen]);

  const handleCategoryClick = () => {
    setCatalogIsOpen(true);
  };

  return (
    <div className="direction">
      <h2 className="h2-in-grid">Выбери направление</h2>
      <section className="grid">
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Programm}
              alt="Иконка направления по программированию"
              className="svg-card"
            />
            <h4 className="direction-name">Программирование</h4>
          </div>
          <p className="grid-text">
            Python-разработка
            <br />
            Web-разработка
            <br />
            Мобильная разработка
            <br />
            JavaScript-разработка
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Marketing}
              alt="Иконка направления по маркетингу"
              className="svg-card"
            />
            <h4 className="direction-name">Маркетинг</h4>
          </div>
          <p className="grid-text">
            SMM-продвижение
            <br />
            Интернер-разработка
            <br />
            Руководство маркетингом
            <br />
            Копирайтинг
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={AnalyticsLogo}
              alt="Иконка направления по аналитике"
              className="svg-card"
            />
            <h4 className="direction-name">Аналитика</h4>
          </div>
          <p className="grid-text">
            Финансовая-аналитика
            <br />
            Бизнес-аналитика
            <br />
            Data Science
            <br />
            Все курсы по Big Data
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Design}
              alt="Иконка направления по дизайну"
              className="svg-card"
            />
            <h4 className="direction-name">Дизайн</h4>
          </div>
          <p className="grid-text">
            Web-дизайн
            <br />
            3D-моделирование
            <br />
            Графичесмкий дизайн
            <br />
            Отрисовка иллюстраций
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Accounting}
              alt="Иконка направления по финансам"
              className="svg-card"
            />
            <h4 className="direction-name">Финансы</h4>
          </div>
          <p className="grid-text">
            Запуск стартапов
            <br />
            Финансы для руководителей
            <br />
            Управление продажами
            <br />
            Маркетплейсы и e-commerce
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Webcontent}
              alt="Иконка направления по веб-контенту"
              className="svg-card"
            />
            <h4 className="direction-name">Контент</h4>
          </div>
          <p className="grid-text">
            Финансовая-аналитика
            <br />
            Бизнес-аналитика
            <br />
            Data Science
            <br />
            Все курсы по Big Data
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Psychology}
              alt="Иконка направления по психологии"
              className="svg-card"
            />
            <h4 className="direction-name">Психология</h4>
          </div>
          <p className="grid-text">
            Python-разработка
            <br />
            Web-разработка
            <br />
            Мобильная разработка
            <br />
            JavaScript-разработка
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={Management}
              alt="Иконка направления по менеджменту"
              className="svg-card"
            />
            <h4 className="direction-name">Управление</h4>
          </div>
          <p className="grid-text">
            SMM-продвижение
            <br />
            Интернер-разработка
            <br />
            Руководство маркетингом
            <br />
            Копирайтинг
          </p>
        </div>
        <div className="grid-card" onClick={handleCategoryClick}>
          <div className="name">
            <img
              src={AnalyticsLogo}
              alt="Иконка направления по чему-то там"
              className="svg-card"
            />
            <h4 className="direction-name">Разное</h4>
          </div>
          <p className="grid-text">
            Финансовая-аналитика
            <br />
            Бизнес-аналитика
            <br />
            Data Science
            <br />
            Все курсы по Big Data
          </p>
        </div>
      </section>
    </div>
  );
};

export default Grid;
