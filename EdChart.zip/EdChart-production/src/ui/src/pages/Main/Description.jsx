import './description.scss';
import mark from '../../assets/images/svg/mark.svg';
import com from '../../assets/images/svg/com.svg';
import Ex from '../../assets/images/svg/exa.svg';
import arrow from '../../assets/images/svg/arrow.svg';
import remote from '../../assets/images/svg/Remote_education.svg';

const Descroption = ({ catalogState }) => {
  const [, setIsOpen] = catalogState;

  return (
    <>
      <div className="description">
        <div className="first">
          <div className="about">
            <h1 className="h1-for-discription h1-style">
              Поиск и сравнение лучших&nbsp;
              <span className="h1-different h1-style">онлайн курсов</span>
            </h1>
            <h3 className="h3-for-discription">
              Самая точная информация о курсах и реальное место в рейтинге школ!
            </h3>
            <div className="group-button-first">
              <button
                type="button"
                className="cataloge-button"
                onClick={() => setIsOpen(true)}
              >
                <p className="look-catalog"> Смотреть каталог</p>
                <img src={arrow} alt="Иконка стрелка" className="picsvg" />
              </button>
            </div>
          </div>
        </div>
        <div className="second">
          <img src={remote} alt="Фоновая картинка" className="remout" />
          <div className="plash-ex plash">
            <img src={Ex} alt="Иконка экспертизы" className="ex" />
            <h5 className="h5">Независимая экспертиза</h5>
          </div>
          <div className="plash-com plash">
            <img src={com} alt="Иконка сравнения" className="com" />
            <h5 className="h5">Сравнение курсов</h5>
          </div>
          <div className="plash-mark plash">
            <img src={mark} alt="Иконка оценка" className="mark" />
            <h5 className="h5">40 критериев оценки</h5>
          </div>
        </div>
      </div>
      <div className="about-project">
        <h2 className="h2-for-discription">О проекте</h2>
        <div className="vertical-line" />
        <p className="text">
          Наша цель - не заработать на продаже курсов, а предложить вам те
          курсы, которые являются лучшими, несмотря на стоимость обучения и
          размер компании! На основе своей экспертизы мы внедрили более 40
          критериев, по которым оцениваем каждый курс и определяем его реальное
          место на рынке образования. Переходи по ссылке, сравнивай курсы между
          собой и выбирай то, что нужно тебе!
        </p>
      </div>
    </>
  );
};

export default Descroption;
