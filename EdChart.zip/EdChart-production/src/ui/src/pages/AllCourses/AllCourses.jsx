import './allCourses.scss';
import Card from '../../components/Card/Card';

const Coursecsarde = () => {
  const cardData = [
    {
      title: 'Инженер по тестированию',
      content: `Вы научитесь находить ошибки в работе сайтов и приложений с помощью Java, JavaScript или`,
      button: 'Подробнее',
      id: 1,
      img: 'https://cdn1.ozone.ru/s3/multimedia-w/wc1000/6368428532.jpg',
      logo: 'https://cdn1.ozone.ru/s3/multimedia-w/wc1000/6368428532.jpg',
      rating: 5,
      namerating: '5.0',
    },
  ];
  return (
    <div className="direction">
      <h2 className="h2">Выбери курс</h2>
      <div className="grid-course">
        <Card {...cardData[0]} />
        <Card {...cardData[0]} />
        <Card {...cardData[0]} />
        <Card {...cardData[0]} />
        <Card {...cardData[0]} />
        <Card {...cardData[0]} />
      </div>
    </div>
  );
};

export default Coursecsarde;
