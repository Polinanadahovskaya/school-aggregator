import { Rating } from '@mui/material';

import './SchoolHeader.scss';

import {
  negatives,
  neutral,
  positives,
} from '../../assets/images/svg/school-rating/reviews/index';

const SchoolHeader = (props) => {
  const {
    logo,
    rating,
    feedbacks,
    positiveFeedbacks,
    negativeFeedbacks,
    neutralFeedbacks,
    description,
    link,
  } = props;

  return (
    <div className="school_header">
      <div className="header_info">
        <img src={logo} alt="school logo" className="info_image" />
        <div className="school-rating">
          <div className="school-rating-stars">
            <Rating value={rating} precision={0.5} readOnly size="large" />
            <span className="rating-value">{rating}</span>
          </div>
          <p className="school-reviews-count">{feedbacks} отзывов</p>
          <div className="school-reviews-diversity">
            <div className="reviews">
              <img src={positives} alt="positive" />
              <span className="positive">{positiveFeedbacks}</span>
            </div>
            <div className="reviews">
              <img src={neutral} alt="positive" />
              <span className="neutral">{neutralFeedbacks}</span>
            </div>
            <div className="reviews">
              <img src={negatives} alt="positive" />
              <span className="negative">{negativeFeedbacks}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="header_description">
        <p>{description}</p>
        <button type="button" className="school-courses_btn">
          <a href={link} target="_blank" rel="noopener noreferrer">
            Смотреть все курсы
          </a>
        </button>
      </div>
    </div>
  );
};

export default SchoolHeader;
