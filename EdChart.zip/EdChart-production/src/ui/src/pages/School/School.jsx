import { useParams } from 'react-router-dom';
import { useState } from 'react';
import { useQuery, useInfiniteQuery } from 'react-query';
import {
  FormControl,
  Select,
  MenuItem,
  LinearProgress,
  CircularProgress,
} from '@mui/material';
import getSchoolData, { getBestCourses } from '../../api/schoolApi';
import getReviewsPaginated from '../../api/reviewsApi';
import SchoolHeader from './SchoolHeader';
import LoadMore from '../../components/LoadMore/LoadMore';
import Review from '../../components/Review/Review';
import Card from '../../components/Card/Card';
import FeedbackModal from '../../components/FeedbackModal/FeedbackModal';

import './school.scss';

const School = () => {
  const [sortReviews, setSortReviews] = useState('popular');

  const params = useParams();
  const { school } = params;

  const {
    data: schoolData,
    isLoading: isSchoolDataLoading,
    error: schoolDataError,
  } = useQuery(['schoolData', school], () => getSchoolData(school));

  const schoolId = schoolData?.id;

  const {
    data: feedbacks,
    isLoading: isFeedbacksLoading,
    error: feedbacksError,
    hasNextPage,
    fetchNextPage,
    isFetchingNextPage,
  } = useInfiniteQuery({
    queryKey: ['feedbackDataPaginated', schoolId],
    queryFn: ({ pageParam = 0 }) => getReviewsPaginated(schoolId, pageParam),
    getNextPageParam: (lastPage, pages) => {
      if (lastPage.hasNext) {
        return pages.length + 1;
      }
      return undefined;
    },
    enabled: !!schoolId,
  });

  const {
    data: bestCourses,
    isLoading: bestCoursesLoading,
    error: bestCoursesError,
  } = useQuery(['bestCourses', schoolId], () => getBestCourses(schoolId), {
    enabled: !!schoolId,
  });

  const handleReviewsSortChange = (event) => {
    setSortReviews(event.target.value);
  };

  const formControlSx = {
    m: 1,
    minWidth: 120,
    '& .Mui-focused .MuiOutlinedInput-notchedOutline': {
      border: 'none',
    },
  };

  const selectSx = {
    color: '#666DA5',
    fontWeight: '600',
    fontSize: '22px',
    '.MuiOutlinedInput-notchedOutline': { border: 'none' },
    '.MuiSelect-select': { paddingLeft: '0', paddingTop: '10px' },
  };

  // feedback modal state
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  if (isSchoolDataLoading) {
    return <LinearProgress />;
  }

  if (schoolDataError) {
    return (
      <p>Произошла ошибка при загрузке данных, попробуйте обновить страницу</p>
    );
  }

  let feedbackData;
  if (isFeedbacksLoading) {
    feedbackData = <CircularProgress />;
  } else if (feedbacksError) {
    feedbackData = <p>Произошла ошибка при загрузке отзывов</p>;
  } else {
    feedbackData = feedbacks.pages.map((page) => {
      return page.commentDtoList.map((feedback) => (
        <Review key={feedback.id} {...feedback} />
      ));
    });
  }

  let bestCoursesData;
  if (bestCoursesLoading) {
    bestCoursesData = <CircularProgress />;
  } else if (bestCoursesError) {
    bestCoursesData = <p>Произошла ошибка при загрузке курсов</p>;
  } else {
    bestCoursesData = bestCourses.map((card) => {
      return <Card key={card.id} {...card} />;
    });
  }

  return (
    <div className="school-container">
      <SchoolHeader {...schoolData} />
      <div className="school-reviews">
        <div className="best-courses">
          <h1 className="best-courses_header">Лучшие курсы школы</h1>
          {bestCoursesData}
        </div>
        <div className="best-reviews">
          <h1 className="best-reviews_header">Отзывы о курсах</h1>
          <div className="best-reviews_sort">
            <span>Сортировать:</span>
            <FormControl sx={formControlSx} size="small">
              <Select
                sx={selectSx}
                labelId="demo-select-small"
                id="demo-select-small"
                value={sortReviews}
                label="Reviews sort"
                onChange={handleReviewsSortChange}
              >
                <MenuItem value="popular">По популярности</MenuItem>
                <MenuItem value="price">По стоимости</MenuItem>
              </Select>
            </FormControl>
            <div>
              <button
                type="button"
                onClick={handleOpen}
                className="leave-review_btn"
              >
                Оставить отзыв
              </button>
              <FeedbackModal
                open={open}
                handleClose={handleClose}
                schoolId={schoolId}
              />
            </div>
          </div>
          {feedbackData}
          {!!schoolData.feedbacks && !schoolData && (
            <LoadMore
              hasNextPage={hasNextPage}
              fetchNextPage={fetchNextPage}
              isFetchingNextPage={isFetchingNextPage}
              openModal={handleOpen}
            />
          )}
          {!schoolData.feedbacks && <p>Отзывов пока нет</p>}
        </div>
      </div>
    </div>
  );
};

export default School;
