#!/bin/bash
echo "I am here!"
npm install
npm run dev