/* eslint-disable import/no-extraneous-dependencies */
import { defineConfig } from 'vite';
import { VitePluginFonts } from 'vite-plugin-fonts';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [
    react(),
    VitePluginFonts({
      google: {
        families: ['Inter'],
      },
    }),
  ],
  css: {
    devSourcemap: true,
  },
  resolve: {
    alias: {
      '@images': path.resolve(__dirname, './src/assets/images'),
      '@styles': path.resolve(__dirname, './src/styles/'),
    },
  },
  server: {
    host: true,
    watch: {
      usePolling: true,
    },
  },
});
