package app.mapperTest;

import app.dto.UserDto;
import app.mapper.UserMapper;
import app.model.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class UserMapperTest {

    @Test
    void mapUserDtoToUser() {

        UserDto dto = UserDto.builder()
                .id(1L)
                .firstName("FirstNameOne")
                .lastName("LastnameOne")
                .email("First.One@mail.com")
                .phone("79998887755")
                .password("1234567")
                .confirmPassword("1234567")
                .build();

        User entity = UserMapper.USER_MAPPER.mapFromDto(dto);

        Assertions.assertEquals(dto.getId(), entity.getId());
        Assertions.assertEquals(dto.getFirstName(), entity.getFirstName());
        Assertions.assertEquals(dto.getLastName(), entity.getLastName());
        Assertions.assertEquals(dto.getEmail(), entity.getEmail());
        Assertions.assertEquals(dto.getPhone(), entity.getPhone());
        Assertions.assertEquals(dto.getPassword(), entity.getPassword());
        Assertions.assertEquals(dto.getConfirmPassword(), entity.getPassword());

    }

    @Test
    void mapUserToUserDto() {

        User entity = User.builder()
                .id(1L)
                .firstName("FirstNameOne")
                .lastName("LastnameOne")
                .email("First.One@mail.com")
                .phone("79998887755")
                .password("1234567")
                .build();

        UserDto dto = UserMapper.USER_MAPPER.mapToDto(entity);

        Assertions.assertEquals(entity.getId(), dto.getId());
        Assertions.assertEquals(entity.getFirstName(), dto.getFirstName());
        Assertions.assertEquals(entity.getLastName(), dto.getLastName());
        Assertions.assertEquals(entity.getEmail(), dto.getEmail());
        Assertions.assertEquals(entity.getPhone(), dto.getPhone());
        Assertions.assertEquals(entity.getPassword(), dto.getPassword());
        Assertions.assertEquals(entity.getPassword(), dto.getConfirmPassword());

    }

}
