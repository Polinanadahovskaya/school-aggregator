#        to start up docker from this directory

docker-compose up -d

#        to stop docker please run

docker-compose down -v